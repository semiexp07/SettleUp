rootProject.name = "settleup"
