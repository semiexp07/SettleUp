package com.sleevesup.settleup.entity

import javax.persistence.*

@Entity
@Table(name="member")
data class GroupMemberEntity (

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    val id:Int?=null,

    @Column(name="userid")
    val userId:Int,

    @Column(name="groupid")
    val groupId:Int



)