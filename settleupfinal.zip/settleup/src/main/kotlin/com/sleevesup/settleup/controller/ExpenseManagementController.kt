package com.sleevesup.settleup.controller

import com.sleevesup.settleup.dto.ExpenseManagementRequestDto
import com.sleevesup.settleup.dto.ExpenseManagementResponseDto
import com.sleevesup.settleup.service.ExpenseManagementService
import org.springframework.web.bind.annotation.GetMapping
import org.springframework.web.bind.annotation.PathVariable
import org.springframework.web.bind.annotation.PostMapping
import org.springframework.web.bind.annotation.RequestBody
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.RestController

@RestController
@RequestMapping("/api/v1/expenses")
class ExpenseManagementController (
    private var expenseManagementService: ExpenseManagementService
){

    @PostMapping("total")
    fun total(@RequestBody userEmail:ExpenseManagementRequestDto):ExpenseManagementResponseDto?{
        var response=expenseManagementService.userExpense(userEmail)
        return response
    }
    @GetMapping("friend/{email}")
    fun findAllFriendExpense(@PathVariable email:String):Map<String,Int>?{
       return expenseManagementService.friendExpense(email)
    }
}