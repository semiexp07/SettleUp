package com.sleevesup.settleup.validation

import com.sleevesup.settleup.entity.FriendEntity
import com.sleevesup.settleup.entity.UserEntity

object GroupValidation {

    fun isUser(user:UserEntity):Boolean{
        if(user!=null)
            return true
        return false
    }

    fun isFriend(user:UserEntity):Boolean{
        if(user!=null)
            return true
        return false
    }
}