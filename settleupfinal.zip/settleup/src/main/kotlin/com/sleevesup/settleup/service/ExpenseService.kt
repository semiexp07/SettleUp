package com.sleevesup.settleup.service

import com.sleevesup.settleup.dto.ExpenseRequestDto
import com.sleevesup.settleup.entity.ExpenseEntity

interface ExpenseService {

    fun createExpense(request:ExpenseRequestDto):ExpenseEntity
}