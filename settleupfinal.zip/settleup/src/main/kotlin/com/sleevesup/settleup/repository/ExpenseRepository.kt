package com.sleevesup.settleup.repository

import com.sleevesup.settleup.entity.ExpenseEntity
import org.springframework.data.jpa.repository.JpaRepository
import org.springframework.stereotype.Repository

@Repository
interface ExpenseRepository:JpaRepository<ExpenseEntity,Int>