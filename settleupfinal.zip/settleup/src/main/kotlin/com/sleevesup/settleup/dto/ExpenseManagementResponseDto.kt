package com.sleevesup.settleup.dto

data class ExpenseManagementResponseDto (
    var userName:String,
    var userMail:String,
    var userTotalPay:Long,
    var userTotalReceive:Long
)