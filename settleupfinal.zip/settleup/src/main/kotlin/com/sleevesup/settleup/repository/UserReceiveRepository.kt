package com.sleevesup.settleup.repository

import com.sleevesup.settleup.entity.UserExpenseEntity
import com.sleevesup.settleup.entity.UserReceiveEntity
import org.springframework.data.jpa.repository.JpaRepository
import org.springframework.stereotype.Repository

@Repository
interface UserReceiveRepository :JpaRepository<UserReceiveEntity,Int>{
    fun findAllByUserId(id:Int):List<UserReceiveEntity>
}