package com.sleevesup.settleup.entity

import com.fasterxml.jackson.annotation.JsonIgnore
import com.sleevesup.settleup.dto.GroupResponseDto
import org.hibernate.annotations.Fetch
import org.hibernate.annotations.FetchMode
import javax.persistence.*

@Entity
@Table(name = "groups")
data class GroupEntity(
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    val id:Int?=null,

    @Column(name="groupname")
    var groupName:String,

    @Column(name="groupdescription")
    var groupDescription:String,

    @ManyToMany(cascade = [CascadeType.ALL], fetch = FetchType.LAZY)
    @Fetch(value = FetchMode.SUBSELECT)
    @JsonIgnore
    @JoinTable( name = "member",
        joinColumns = [JoinColumn(name="groupid")],
        inverseJoinColumns = [JoinColumn(name = "userid")]
    )
    var user:List<UserEntity>?

){
    fun groupResponse():GroupResponseDto{
        val mem= mutableListOf<String>()
        
        val iterator = user?.listIterator()
        if (iterator != null) {
            while (iterator.hasNext()) {

                val memName=iterator.next().name
                mem.add(memName)
            }
        }

        return GroupResponseDto(groupName =groupName, groupDescription =groupDescription, members = mem)
    }
}
