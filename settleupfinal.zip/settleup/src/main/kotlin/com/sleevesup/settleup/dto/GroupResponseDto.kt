package com.sleevesup.settleup.dto

import com.sleevesup.settleup.entity.UserEntity

data class GroupResponseDto(
    var groupName:String,
    var groupDescription:String,
    var members:List<String>?
)