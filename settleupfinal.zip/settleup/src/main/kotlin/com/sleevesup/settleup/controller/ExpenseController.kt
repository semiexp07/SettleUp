package com.sleevesup.settleup.controller

import com.sleevesup.settleup.dto.ExpenseRequestDto
import com.sleevesup.settleup.dto.GroupRequestDto
import com.sleevesup.settleup.entity.ExpenseEntity
import com.sleevesup.settleup.entity.GroupEntity
import com.sleevesup.settleup.service.ExpenseService
import org.springframework.stereotype.Controller
import org.springframework.web.bind.annotation.PostMapping
import org.springframework.web.bind.annotation.RequestBody
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.RestController

@RestController
@RequestMapping("/api/v1/expense")
class ExpenseController(
    private var expenseService: ExpenseService
) {

    @PostMapping("create")
    fun create(@RequestBody input: ExpenseRequestDto): ExpenseEntity {
        var response = expenseService.createExpense(input)
        return response
    }

}