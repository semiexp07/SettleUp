package com.sleevesup.settleup.repository

import com.sleevesup.settleup.entity.GroupEntity
import org.springframework.data.jpa.repository.JpaRepository
import org.springframework.stereotype.Repository

@Repository
interface GroupRepository:JpaRepository<GroupEntity,Int>