package com.sleevesup.settleup.service

import com.sleevesup.settleup.dto.ExpenseManagementRequestDto
import com.sleevesup.settleup.dto.ExpenseManagementResponseDto
import com.sleevesup.settleup.dto.ExpenseManagementResponseDtoFriend
import org.springframework.stereotype.Service


interface ExpenseManagementService{
    fun userExpense(userMail:ExpenseManagementRequestDto):ExpenseManagementResponseDto?

    fun friendExpense(userMail:String):Map<String,Int>?
}