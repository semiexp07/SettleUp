package com.sleevesup.settleup.service

import com.sleevesup.settleup.dto.ExpenseManagementRequestDto
import com.sleevesup.settleup.dto.ExpenseManagementResponseDto
import com.sleevesup.settleup.dto.ExpenseManagementResponseDtoFriend
import com.sleevesup.settleup.repository.GroupMemberRepository
import com.sleevesup.settleup.repository.UserExpenseRepository
import com.sleevesup.settleup.repository.UserReceiveRepository
import com.sleevesup.settleup.repository.UserRepository
import org.springframework.stereotype.Service

@Service
class ExpenseManagementServiceImpl(
    private var userRepository: UserRepository,
    private var userExpenseRepository: UserExpenseRepository,
    private var userReceiveRepository: UserReceiveRepository,
    private var groupMemberRepository: GroupMemberRepository
):ExpenseManagementService {

    override fun userExpense(userMail: ExpenseManagementRequestDto): ExpenseManagementResponseDto?{
        var user=userRepository.findByEmail(userMail.userEmail)
        if(user!=null){
            var userExpense= user.id?.let { userExpenseRepository.findAllByUserId(it) }
            var userReceive= user.id?.let { userReceiveRepository.findAllByUserId(it) }
            var totalPay:Long=0
            var totalReceive:Long=0

            var it= userExpense?.listIterator()
            if (it != null) {
                while(it.hasNext()){
                    totalPay +=it.next().amount
                }
            }
            var it2= userReceive?.listIterator()
            if (it2 != null) {
                while(it2.hasNext()){
                    totalReceive +=it2.next().amount
                }
            }

            var response=ExpenseManagementResponseDto(userName= user.name , userMail = user.email , userTotalPay = -totalPay, userTotalReceive = +totalReceive)
            return response
        }

        return null

    }


    override fun friendExpense(userMail:String): Map<String,Int>? {
        var user= userRepository.findByEmail(userMail) ?: return null
        var allGroupIds=groupMemberRepository.findAllByUserId(3)

        var response= mutableMapOf<String, Int>()

        var it=allGroupIds.listIterator()
        while (it.hasNext()){
            response.put("friendInGroup ${it.next().groupId}",100)
        }

         return response
    }


}