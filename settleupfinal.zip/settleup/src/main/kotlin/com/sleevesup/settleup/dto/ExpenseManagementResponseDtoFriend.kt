package com.sleevesup.settleup.dto

data class ExpenseManagementResponseDtoFriend (
    var map:Map<String,Long>
)