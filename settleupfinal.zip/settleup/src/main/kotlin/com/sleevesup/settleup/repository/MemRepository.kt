package com.sleevesup.settleup.repository

import com.sleevesup.settleup.entity.FriendEntity

import org.springframework.data.jpa.repository.JpaRepository

interface MemRepository: JpaRepository<FriendEntity, Int>