package com.sleevesup.settleup.entity

import javax.persistence.*


@Entity
@Table(name="mem")
data class MemberEntity (

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    val id:Int?=null,

    @Column(name="userid")
    val userId:Int,

    @Column(name="groupid")
    val groupId:Int

)