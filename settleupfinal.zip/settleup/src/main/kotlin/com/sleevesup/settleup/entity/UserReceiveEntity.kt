package com.sleevesup.settleup.entity

import javax.persistence.*

@Entity
@Table(name="userreceive")
data class UserReceiveEntity (
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    val id:Int?=null,


    @Column(name="userid")
    var userId:Int,


    @Column
    var amount:Int


)
