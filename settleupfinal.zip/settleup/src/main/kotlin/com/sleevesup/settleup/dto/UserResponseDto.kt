package com.sleevesup.settleup.dto

import com.sleevesup.settleup.entity.GroupEntity

data class UserResponseDto (

    var name:String,
    var mobile:String,
    var email:String,
    var address:String,
    var age:Int,
    var group:List<GroupEntity>?
)