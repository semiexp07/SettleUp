package com.sleevesup.settleup.dto

import com.sleevesup.settleup.entity.UserEntity

data class FriendResponseDto (
    var friendList:List<UserEntity>?
)