package com.sleevesup.settleup.service

import com.sleevesup.settleup.dto.ExpenseRequestDto
import com.sleevesup.settleup.entity.ExpenseEntity
import com.sleevesup.settleup.entity.GroupMemberEntity
import com.sleevesup.settleup.entity.UserExpenseEntity
import com.sleevesup.settleup.entity.UserReceiveEntity
import com.sleevesup.settleup.repository.*
import com.sleevesup.settleup.validation.ExpenseValidation.isGroupMember
import org.springframework.stereotype.Service
import kotlin.reflect.jvm.internal.impl.descriptors.Visibilities.Private

@Service
class ExpenseServiceImpl(

    private val expenseRepository: ExpenseRepository,
    private val userExpenseRepository:UserExpenseRepository,
    private val userReceiveRepository: UserReceiveRepository,
    private val groupRepository:GroupRepository,
    private val groupMemberRepository:GroupMemberRepository,
    private  val userRepository: UserRepository


    ) :ExpenseService{

    override fun createExpense(request: ExpenseRequestDto): ExpenseEntity {
        val response=expenseRepository.save(request.toEntityExpense())


        var memberTable= mutableListOf<GroupMemberEntity>()

        memberTable=groupMemberRepository.findAllByGroupId(request.groupId).toMutableList()


        val amount:Int = (request.expense/(memberTable.size ))
        val iterator = memberTable.listIterator()
        while (iterator.hasNext()) {


            val userExpense= response.id?.let { UserExpenseEntity(userId = iterator.next().userId.hashCode(),amount = amount , expenseID = it) }
            if (userExpense != null) {
                userExpenseRepository.save(userExpense)
            }


        }


         val userReceive=UserReceiveEntity(userId = request.paidBy, amount = (request.expense)-amount)
         userReceiveRepository.save(userReceive)


        return response
    }

}