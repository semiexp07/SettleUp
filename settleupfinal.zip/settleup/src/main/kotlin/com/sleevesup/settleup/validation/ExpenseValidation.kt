package com.sleevesup.settleup.validation

import com.sleevesup.settleup.entity.UserEntity

object ExpenseValidation {

    fun isGroupMember(user:UserEntity):Boolean{
        if(user!=null)
            return true
        return false
    }
}