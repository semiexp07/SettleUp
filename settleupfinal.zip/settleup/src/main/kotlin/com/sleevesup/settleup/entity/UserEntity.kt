package com.sleevesup.settleup.entity

import com.fasterxml.jackson.annotation.JsonIgnore
import com.fasterxml.jackson.annotation.JsonIgnoreProperties
import com.sleevesup.settleup.dto.UserResponseDto
import org.hibernate.annotations.Fetch
import org.hibernate.annotations.FetchMode
import java.net.Inet4Address
import javax.persistence.*

@Entity
@Table(name="userdata")
data class UserEntity(

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    val id: Int?=null,

    @Column
    var name:String,

    @Column
    var mobile:String,

    @Column
    var age:Int,

    @Column
    var password:String,

    @Column(unique=true)
    var email:String,

    @Column
    var groupid:Int,

    @ManyToMany(cascade = [CascadeType.ALL], fetch = FetchType.LAZY)
    @Fetch(value = FetchMode.SUBSELECT)

    @JoinTable( name="member",
        joinColumns = [JoinColumn(name="userid")],
        inverseJoinColumns = [JoinColumn(name="groupid")]
    )
    var group:List<GroupEntity>?



) {
    fun userResponse(): UserResponseDto {
        return UserResponseDto(
            name = name,
            mobile = mobile,
            address = "xyz",
            email = email,
            group = group,
            age = age)
    }
}
