package com.sleevesup.settleup.service

import com.sleevesup.settleup.dto.FriendRequestDto
import com.sleevesup.settleup.dto.GroupRequestDto
import com.sleevesup.settleup.dto.GroupResponseDto
import com.sleevesup.settleup.entity.GroupEntity

interface GroupService{

     fun create(group:GroupRequestDto):GroupEntity?

     fun get(id:Int):GroupResponseDto?

     fun createFriend(request:FriendRequestDto):String?

     fun findFriend(id:Int):List<String>?
}