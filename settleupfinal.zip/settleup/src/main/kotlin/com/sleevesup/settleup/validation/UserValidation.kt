package com.sleevesup.settleup.validation

object UserValidation {

    fun isMobileNumber(num:String):Boolean{
        if(num.length<=13)
            return true
        return false
    }

    fun isEmail(mail:String):Boolean{
        if(mail.endsWith("@gmail.com",true))
            return true
        return false
    }
}