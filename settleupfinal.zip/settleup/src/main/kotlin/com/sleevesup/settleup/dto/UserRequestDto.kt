package com.sleevesup.settleup.dto

import com.sleevesup.settleup.entity.GroupEntity
import com.sleevesup.settleup.entity.UserEntity

data class UserRequestDto (
    var name:String,
    var mobile:String,
    var email:String,
    var groupid:Int,
    var age:Int,
    var password:String

    ){

    fun toEntity():UserEntity{

        return UserEntity(name=name, mobile = mobile, age = age, password = password,email=email, groupid = groupid, group = null)
    }
}