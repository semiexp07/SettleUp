package com.sleevesup.settleup.controller
import com.sleevesup.settleup.dto.UserRequestDto
import com.sleevesup.settleup.entity.UserEntity
import com.sleevesup.settleup.service.UserService
import org.springframework.http.HttpStatus

import org.springframework.http.ResponseEntity
import org.springframework.web.bind.annotation.*

@RestController
@RequestMapping("/api/v1/user")
class UserController (
    private val userService: UserService

){
    //    create is for creating new user and add it to table userdata
    @PostMapping("create")
    fun create(@RequestBody use:UserRequestDto):ResponseEntity<UserEntity>{
        val response=userService.createUser(use)
        if(response.id!=null)
            return ResponseEntity(response,HttpStatus.CREATED)
        else
            return ResponseEntity(response,HttpStatus.NOT_ACCEPTABLE)
    }

    @GetMapping("{id}")
    fun get(@PathVariable id:Int):ResponseEntity<UserEntity>{
        val response=userService.getUser(id)
        return ResponseEntity.ok(response)
    }

    //    to update any user details
    @PutMapping("update")
    fun update(@RequestBody user:UserRequestDto):ResponseEntity<Any>{
        val response=userService.updateUser(user)
        return ResponseEntity.ok(response)
    }

    //    to delete any user from map
    @DeleteMapping("{id}")
    fun delete(@PathVariable id:Int):ResponseEntity<Any>{
        val response=userService.deleteUser(id)
        return ResponseEntity.ok(response)
    }

    // to display all the user
    @GetMapping("display")
    fun display():ResponseEntity<List<UserEntity>?>{
        val response=userService.displayUser()
        return ResponseEntity.ok(response)
    }

}