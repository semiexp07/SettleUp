package com.sleevesup.settleup.repository

import com.sleevesup.settleup.entity.UserEntity
import org.springframework.data.jpa.repository.JpaRepository
import org.springframework.stereotype.Repository

@Repository
interface UserRepository: JpaRepository<UserEntity, Int>{

    fun findByEmail(email:String):UserEntity
    fun findNameById(id:Int):String
}