package com.sleevesup.settleup.dto

data class ExpenseManagementRequestDto (
    var userEmail:String
)