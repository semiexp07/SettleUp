package com.sleevesup.settleup.dto

data class FriendRequestDto (
    var userEmail:String,
    var friendEmail:String
)