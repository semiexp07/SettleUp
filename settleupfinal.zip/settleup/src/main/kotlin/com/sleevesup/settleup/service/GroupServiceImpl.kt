package com.sleevesup.settleup.service

import com.sleevesup.settleup.dto.FriendRequestDto
import com.sleevesup.settleup.dto.GroupResponseDto
import com.sleevesup.settleup.entity.*
import com.sleevesup.settleup.repository.*
import com.sleevesup.settleup.validation.GroupValidation.isFriend
import com.sleevesup.settleup.validation.GroupValidation.isUser
import org.springframework.stereotype.Service
import com.sleevesup.settleup.dto.GroupRequestDto as GroupRequestDto1

@Service
class GroupServiceImpl (
    private val groupRepository: GroupRepository,
    private val memberRepository: GroupMemberRepository,
    private val memRepository: MemRepository,
    private val userRepository: UserRepository

):GroupService{

    override fun create(group: GroupRequestDto1): GroupEntity? {
        val users =group.groupMembers
        val groupData=group.toGroupEntity()
        val response= groupRepository.save(groupData)
        val iterator = users.listIterator()
        while (iterator.hasNext()) {
            val userId = iterator.next().hashCode()-48
            val groupId=response.id.hashCode()
            val memberEntity=GroupMemberEntity(userId=userId, groupId = groupId)

            val resp = memberRepository.save(memberEntity)
        }

        return response
    }

    override fun get(id: Int): GroupResponseDto? {
        val group=groupRepository.findById(id).get()



        return group.groupResponse()

    }


//    Friend's APIs services are from here.........................
    override fun createFriend(request: FriendRequestDto): String {
         val user = userRepository.findByEmail(request.userEmail)
         val friend = userRepository.findByEmail(request.friendEmail)

          if(isUser(user) && isFriend(friend)){
              val frnd = mutableListOf<Int>()
              frnd.add(user.id!!)
              frnd.add(friend.id!!)

              val group = GroupRequestDto1(groupName = "friend", groupDescription = "friend", groupMembers = frnd)
              val response = groupRepository.save(group.toGroupEntity())

              val userId=user.id.hashCode()
              val friendId=friend.id.hashCode()
              val friendGroupId=response.id.hashCode()

              val friendRelation=FriendEntity(userId=userId, friendGroupId = friendGroupId)
              memRepository.save(friendRelation)
              val friendRelation2=FriendEntity(userId=friendId, friendGroupId = friendGroupId)
                   memRepository.save(friendRelation2)

              if(response!=null)
                  return "You both are friends now"

              return "Can't be friends"
          }

    return "Can't be friends"
    }



    //              var response= groupRepository.save(groupData)
//              val iterator = users.listIterator()
//              while (iterator.hasNext()) {
//                  val userId = iterator.next().hashCode()-48
//                  val groupId=response.id.hashCode()
//                  val memberEntity=GroupMemberEntity(userId=userId, groupId = groupId)
//                  val memEntity= MemberEntity(userId=userId, groupId = groupId)
//                  memRepository.save(memEntity)
//                  memberRepository.save(memberEntity)
//              }






    override fun findFriend(id: Int): List<String>? {

        val allFriendGroup=memRepository.findAll()
        if(allFriendGroup!=null)
        {
            return null
        }

        val allGroupOfUser= mutableListOf<Int>()

        val allFriendOfUser= mutableListOf<Int>()
        val allFriendName= mutableListOf<String>()

        val iterator = allFriendGroup.listIterator()
        while(iterator.hasNext()){
            val userId = iterator.next().userId.hashCode()
            if(userId==id)
                allGroupOfUser.add(iterator.next().friendGroupId.hashCode())
        }
        val iterator2=allGroupOfUser.iterator()
        while(iterator2.hasNext()){
            val groupIdOfUSer=iterator2.next()
            val iterator3 = allFriendGroup.listIterator()
            while(iterator3.hasNext()){
                val group=iterator3.next().friendGroupId.hashCode()
                if(group==groupIdOfUSer)
                    allFriendOfUser.add(iterator3.next().userId.hashCode())
            }
        }


        val allFriendDetail=userRepository.findAllById(allFriendOfUser)

        val iterator3=allFriendDetail.iterator()
        while(iterator3.hasNext()){
            val name=iterator3.next().name
            allFriendName.add(name)
        }



        return allFriendName

    }







}