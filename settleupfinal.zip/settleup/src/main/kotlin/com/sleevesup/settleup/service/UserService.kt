package com.sleevesup.settleup.service

import com.sleevesup.settleup.dto.UserRequestDto
import com.sleevesup.settleup.dto.UserResponseDto
import com.sleevesup.settleup.entity.UserEntity


interface UserService {

    fun createUser(user: UserRequestDto):UserEntity

    fun getUser(id:Int):UserEntity?

    fun updateUser(user:UserRequestDto):String

    fun deleteUser(id:Int):String

    fun displayUser():List<UserEntity>?
}