package com.sleevesup.settleup.repository

import com.sleevesup.settleup.entity.UserExpenseEntity
import org.springframework.data.jpa.repository.JpaRepository
import org.springframework.stereotype.Repository

@Repository
interface UserExpenseRepository:JpaRepository<UserExpenseEntity,Int>{

    fun findAllByUserId(id:Int):List<UserExpenseEntity>
}