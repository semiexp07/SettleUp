package com.sleevesup.settleup

import mu.KotlinLogging
import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication

@SpringBootApplication
class SettleupApplication

fun main(args: Array<String>) {
    val logger = KotlinLogging.logger {"hello"}
	runApplication<SettleupApplication>(*args)
}
