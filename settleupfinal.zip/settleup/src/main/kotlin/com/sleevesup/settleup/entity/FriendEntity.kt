package com.sleevesup.settleup.entity

import javax.persistence.Column
import javax.persistence.Entity
import javax.persistence.GeneratedValue
import javax.persistence.GenerationType
import javax.persistence.Id
import javax.persistence.Table

@Entity
@Table(name="friends")
data class FriendEntity (

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    val id:Int?=null,


    @Column(name="userid")
    var userId:Int,

    @Column(name="friendgroupid")
    var friendGroupId:Int


)