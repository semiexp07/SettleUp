package com.sleevesup.settleup.service

import com.sleevesup.settleup.dto.UserRequestDto
import com.sleevesup.settleup.entity.UserEntity

import com.sleevesup.settleup.repository.UserRepository
import com.sleevesup.settleup.validation.UserValidation.isEmail
import com.sleevesup.settleup.validation.UserValidation.isMobileNumber
import org.springframework.stereotype.Service


@Service
class UserServiceImpl(private val userRepository: UserRepository ) :UserService{



    override fun createUser(user: UserRequestDto): UserEntity{
        var mob=user.mobile
        var email= user.email

        return if(isMobileNumber(mob)  && isEmail(email)) {
            var userdata:UserEntity=user.toEntity()
            val save = userRepository.save(userdata)
            save
        } else
            throw IllegalArgumentException("Invalid Input")


    }

    override fun getUser(id: Int): UserEntity? {

        return userRepository.findById(id).get()
    }

    override fun updateUser(user: UserRequestDto): String {
        val original=userRepository.findByEmail(user.email)

        return if(original!=null){
            original.age=user.age
            original.mobile=user.mobile
            original.email=user.email
            original.password=user.password
            original.name=user.name
            userRepository.save(original)
            "Done"
        } else
            "User Not Found"

    }


    override fun deleteUser(id: Int): String {
        val user= userRepository.findById(id) ?: return "User Not Found"

        userRepository.deleteById(id)
        return "Deleted"
    }

    override fun displayUser(): List<UserEntity>? {
        return userRepository.findAll()
    }
}