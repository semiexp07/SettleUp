package com.sleevesup.settleup.repository

import com.sleevesup.settleup.entity.GroupMemberEntity
import org.springframework.data.jpa.repository.JpaRepository
import org.springframework.stereotype.Repository

@Repository
interface GroupMemberRepository :JpaRepository<GroupMemberEntity,Int>{


    fun findAllByGroupId(id:Int):List<GroupMemberEntity>
    fun findAllByUserId(id:Int): List<GroupMemberEntity>
    fun findAllUserIdByGroupId(id:Int):List<Int>


}