package com.sleevesup.settleup.entity

import javax.persistence.Column
import javax.persistence.Entity
import javax.persistence.GeneratedValue
import javax.persistence.GenerationType
import javax.persistence.Id
import javax.persistence.Table
//id serial  primary key ,
//groupid int,
//expense int,
//paidby int,
//sharing int
@Entity
@Table(name="expense")
data class ExpenseEntity (
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    val id:Int?=null,

    @Column
    val groupid:Int,

    @Column
    val expense:Int,

    @Column
    val paidby:Int,

    @Column
    val details:String


)