package com.sleevesup.settleup.dto

import com.sleevesup.settleup.entity.GroupEntity
import com.sleevesup.settleup.entity.UserEntity
import jdk.jfr.Description

data class GroupRequestDto (

    var groupName:String,
    var groupDescription:String,
    var groupMembers:List<Int>
)
{
    fun toGroupEntity():GroupEntity{

        return GroupEntity(groupName = groupName, groupDescription = groupDescription, user = null)
    }
}