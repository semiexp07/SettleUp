package com.sleevesup.settleup.dto

import com.sleevesup.settleup.entity.ExpenseEntity


//id serial  primary key ,
//groupid int,
//expense int,
//paidby int,
//sharing int
data class ExpenseRequestDto (
    val groupId:Int,
    val expense:Int,
    val paidBy:Int,
    val details:String
)
{
    fun toEntityExpense():ExpenseEntity{
        return ExpenseEntity(groupid=groupId, expense = expense, paidby = paidBy, details = details)
    }
}