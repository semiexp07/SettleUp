package com.sleevesup.settleup.controller

import com.sleevesup.settleup.dto.FriendRequestDto
import com.sleevesup.settleup.dto.GroupRequestDto
import com.sleevesup.settleup.dto.GroupResponseDto
import com.sleevesup.settleup.entity.GroupEntity
import com.sleevesup.settleup.service.GroupService
import org.springframework.http.ResponseEntity
import org.springframework.web.bind.annotation.GetMapping
import org.springframework.web.bind.annotation.PathVariable
import org.springframework.web.bind.annotation.PostMapping
import org.springframework.web.bind.annotation.RequestBody
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.RestController

@RestController
@RequestMapping("/api/v1/group")
class GroupController(
    private var groupService:GroupService
) {
    @PostMapping("create")
    fun create(@RequestBody input: GroupRequestDto): GroupEntity? {
        return groupService.create(input)
    }

      @GetMapping("{id}")
      fun get(@PathVariable id:Int): ResponseEntity<GroupResponseDto> {
          var response=groupService.get(id)
          return ResponseEntity.ok(response)
      }

      @PostMapping("friend/create")
      fun createFriend(@RequestBody input: FriendRequestDto):ResponseEntity<String>{
          var response=groupService.createFriend(input)
          return ResponseEntity.ok(response)
      }

    @GetMapping("friend/{id}")
    fun findFriend(@PathVariable id: Int): List<String>? {
        return groupService.findFriend(id)
    }
}