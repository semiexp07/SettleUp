package com.sleevesup.settleup

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class SettleupApplicationTests {

	@Test
	fun contextLoads() {
	}

}
