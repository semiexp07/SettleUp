package com.sleevesup.settleup.service

import com.nhaarman.mockitokotlin2.whenever
import com.sleevesup.settleup.dto.ExpenseManagementRequestDto
import com.sleevesup.settleup.dto.ExpenseManagementResponseDto
import com.sleevesup.settleup.repository.GroupMemberRepository
import com.sleevesup.settleup.repository.UserExpenseRepository
import com.sleevesup.settleup.repository.UserReceiveRepository
import com.sleevesup.settleup.repository.UserRepository
import org.junit.jupiter.api.BeforeEach
import org.junit.jupiter.api.Test

import org.junit.jupiter.api.Assertions.*
import org.mockito.Mock
import org.mockito.MockitoAnnotations

class ExpenseManagementServiceImplTest {

    @Mock
    private lateinit var  userRepository: UserRepository
    @Mock
    private lateinit var userExpenseRepository: UserExpenseRepository
    @Mock
    private lateinit var userReceiveRepository: UserReceiveRepository
    @Mock
    private lateinit var groupMemberRepository: GroupMemberRepository
    @Mock
    private lateinit var  expenseManagementService: ExpenseManagementServiceImpl

    @BeforeEach
    fun setUp() {
        MockitoAnnotations.initMocks(this)
        expenseManagementService= ExpenseManagementServiceImpl(userRepository,userExpenseRepository,userReceiveRepository,groupMemberRepository)
    }

    @Test
    fun userExpense() {

        whenever(userRepository.findByEmail("akmadheshiya90@gmail.com")).thenReturn(null)
        whenever(userExpenseRepository.findAllByUserId(1)).thenReturn(null)

//        var response= ExpenseManagementResponseDto(userName="akash" , userMail = "akmadheshiya90@gmail.com" , userTotalPay = -100, userTotalReceive = +500)
        var request= ExpenseManagementRequestDto("akmadheshiya90@gmail.com")



        assertThrows(Exception::class.java) {
            expenseManagementService.userExpense(request)
        }




    }

    @Test
    fun friendExpense() {
    }
}