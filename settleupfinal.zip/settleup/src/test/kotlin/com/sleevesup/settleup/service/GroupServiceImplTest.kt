package com.sleevesup.settleup.service

import com.nhaarman.mockitokotlin2.notNull
import com.nhaarman.mockitokotlin2.whenever
import com.sleevesup.settleup.dto.FriendRequestDto
import com.sleevesup.settleup.dto.GroupRequestDto
import com.sleevesup.settleup.dto.GroupResponseDto
import com.sleevesup.settleup.dto.UserRequestDto
import com.sleevesup.settleup.entity.*
import com.sleevesup.settleup.repository.GroupMemberRepository
import com.sleevesup.settleup.repository.GroupRepository
import com.sleevesup.settleup.repository.MemRepository
import com.sleevesup.settleup.repository.UserRepository
import org.junit.jupiter.api.Test

import org.junit.jupiter.api.Assertions.*
import org.junit.jupiter.api.BeforeEach
import org.mockito.Mock
import org.mockito.MockitoAnnotations
import javax.swing.GroupLayout.Group

class GroupServiceImplTest {

    @Mock
    private lateinit var  groupRepository: GroupRepository
    @Mock
    private lateinit var  memberRepository: GroupMemberRepository
    @Mock
    private lateinit var memRepository: MemRepository
    @Mock
    private lateinit var groupService: GroupServiceImpl
    @Mock
    private lateinit var  userRepository: UserRepository

    @BeforeEach
    fun setUp() {
        MockitoAnnotations.initMocks(this)
        groupService=GroupServiceImpl(groupRepository,memberRepository,memRepository, userRepository )

    }
    @Test
    fun create() {

        var groupName:String="Friends"
        var groupDescription:String="bhai log "
        var groupMembers= mutableListOf<UserEntity>()


        var groupEnt=GroupEntity(groupName=groupName, groupDescription = groupDescription ,id=null,user = groupMembers)
        val mem1= GroupMemberEntity(userId = 1, groupId = 2)
        val mem2=FriendEntity(id=1 ,userId = 2, friendGroupId = 2)
        var list= mutableListOf<Int>()
        list.add(1)
        list.add(2)
        list.add(3)
        var req=GroupRequestDto(groupName,groupDescription,list)
        var listResponse= mutableListOf<String>()




        whenever(groupRepository.save(groupEnt)).thenReturn(groupEnt)
        whenever(memberRepository.save(mem1)).thenReturn(mem1)
        whenever(memRepository.save(mem2)).thenReturn(mem2)



        assertThrows(Exception::class.java) {
            groupService.create(req)
        }



    }

    @Test
    fun get() {

        var listMember= mutableListOf<String>()
        listMember.add("Akash")
        listMember.add("Raj")
        listMember.add("Shubham")
        var groupResponse=GroupResponseDto("Friends","Best friends",listMember)

        whenever(groupRepository.findById(1)).thenReturn(null)

        assertThrows(Exception::class.java) {
            groupService.get(1)
        }



    }

    @Test
    fun createFriend() {

        val frnd = mutableListOf<Int>()
        frnd.add(1)
        frnd.add(2)
        val dto=FriendRequestDto("akmadheshiya@gmail.com","raj@gamil.com")
        val group = GroupRequestDto(groupName = "friend", groupDescription = "friend", groupMembers = frnd)
        val friendRelation=FriendEntity(userId=1, friendGroupId = 2)

        whenever(userRepository.findByEmail("akmadheshiya90@gmail.com")).thenReturn(null)
        whenever(groupRepository.save(group.toGroupEntity())).thenReturn(null)
        whenever(memRepository.save(friendRelation)).thenReturn(null)

        assertThrows(Exception::class.java) {
            groupService.createFriend(dto)
        }



    }

    @Test
    fun findFriend() {

        val mem=FriendEntity(1,2,3)
        val mem2=FriendEntity(1,3,3)
        val mem3=FriendEntity(1,3,3)
        val list= mutableListOf<FriendEntity>()
        list.add(mem)
        list.add(mem2)
        list.add(mem3)


        val user= UserRequestDto("akash","9919301245","akmadheshiya90@gmail.com",2,23,"12345")
        val user2= UserRequestDto("akash","99193012451111","akmadheshiya90@gmail.com",2,23,"12345")

        val user3= UserRequestDto("akash","99193012451111","akmadheshiya90@testabc.com",2,23,"12345")

        var listOfUsers= mutableListOf<UserEntity>()
        listOfUsers.add(user.toEntity())
        listOfUsers.add(user2.toEntity())
        listOfUsers.add(user3.toEntity())
        val allFriendOfUser= mutableListOf<Int>()
        allFriendOfUser.add(1)
        allFriendOfUser.add(2)
        allFriendOfUser.add(3)

        whenever(memRepository.findAll()).thenReturn(list)
        whenever(userRepository.findAllById(allFriendOfUser)).thenReturn(listOfUsers)




           var result= groupService.findFriend(1)

        assertEquals(result , null)



    }
}