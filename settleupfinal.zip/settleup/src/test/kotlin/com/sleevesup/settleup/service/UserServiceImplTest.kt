package com.sleevesup.settleup.service

import com.nhaarman.mockitokotlin2.verifyZeroInteractions
import com.nhaarman.mockitokotlin2.whenever
import com.sleevesup.settleup.dto.UserRequestDto
import com.sleevesup.settleup.entity.UserEntity
import com.sleevesup.settleup.repository.UserRepository
import org.junit.jupiter.api.Assertions.*
import org.junit.jupiter.api.BeforeEach
import org.junit.jupiter.api.Test
import org.mockito.Mock
import org.mockito.MockitoAnnotations
import java.util.*

class UserServiceImplTest {

     @Mock
     private lateinit var userRepository: UserRepository

     private lateinit var userService: UserServiceImpl

    @BeforeEach
    fun setUp() {
        MockitoAnnotations.initMocks(this)
        userService = UserServiceImpl(userRepository)
    }



    @Test
    fun createUser() {
        val user=UserRequestDto("akash","9919301245","akmadheshiya90@gmail.com",2,23,"12345")
        val user2=UserRequestDto("akash","99193012451111","akmadheshiya90@gmail.com",2,23,"12345")
        val user3=UserRequestDto("akash","99193012451111","akmadheshiya90@testabc.com",2,23,"12345")
        whenever(userRepository.save(user.toEntity())).thenReturn(user.toEntity())
        whenever(userRepository.save(user2.toEntity())).thenReturn(user2.toEntity())

        val ex=userService.createUser(user)

        assert(ex.equals(user.toEntity()))
        assertThrows(Exception::class.java) {
            userService.createUser(user2)
        }

        assertThrows(Exception::class.java) {
            userService.createUser(user3)
        }
    }


    @Test
    fun getUser(){
        // Arrange
        val entity = UserEntity(1,"akash","9919301245",23,"123456","akmadheshiya90@gmail.com",1,null)
        whenever(userRepository.findById(1)).thenReturn(Optional.of(entity))

        // Act
        var result = userService.getUser(1)


        //Assert

        if (result != null) {
            assertEquals(entity.name, result.name)
            assertEquals(entity.age, result.age)
            assertEquals(entity.id, result.id)
            assertEquals(entity.email, result.email)
            assertEquals(entity.group, result.group)
            assertEquals(entity.groupid, result.groupid)
            assertEquals(entity.group, result.group)

        }

    }

    @Test
    fun updateUser(){
        //"Arrange"
        val user = UserRequestDto("akash","9919301245","akmadheshiya90@gmail.com",2,23,"12345")
        val entity = UserEntity(1,"akash","9919301245",23,"123456","akmadheshiya90@gmail.com",1,null)
        whenever(userRepository.findByEmail("akmadheshiya90@gmail.com")).thenReturn(entity)

        var result = userService.updateUser(user)
        assertSame("Done",result)

        val user2 = UserRequestDto("vikash","9919307775","akmadheshiya90@gmail.com",6,23,"1234w5")
        val entity2 = UserEntity(1,"akash","9919301245",23,"123456","akmadheshiya90@gmail.com",1,null)

        whenever(userRepository.findByEmail("akmadheshiya@gmail.com")).thenReturn(entity2)

        var result2 = userService.updateUser(user)
        assertSame("Done",result2)


    }

    @Test
    fun deleteUser(){

        val entity = UserEntity(1,"akash","9919301245",23,"123456","akmadheshiya90@gmail.com",1,null)
        whenever(userRepository.findById(1)).thenReturn(Optional.of(entity))


        var result = userService.deleteUser(1)


        assertSame("Deleted",result)


    }


    @Test
    fun displayUser(){
        val entity1 = UserEntity(1,"akash","9919301245",23,"123456","akmadheshiya90@gmail.com",1,null)
        val entity2 = UserEntity(1,"akash","9919301245",23,"123456","akmadheshiya90@gmail.com",1,null)

        var allUser= mutableListOf<UserEntity>()
        allUser.add(entity1)
        allUser.add(entity2)

        whenever(userRepository.findAll()).thenReturn(allUser)

        var result=userService.displayUser()

        assertSame(allUser ,result )

    }

}