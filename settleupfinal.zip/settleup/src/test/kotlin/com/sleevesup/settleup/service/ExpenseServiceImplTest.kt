package com.sleevesup.settleup.service

import com.nhaarman.mockitokotlin2.whenever
import com.sleevesup.settleup.dto.ExpenseRequestDto
import com.sleevesup.settleup.entity.ExpenseEntity
import com.sleevesup.settleup.entity.UserExpenseEntity
import com.sleevesup.settleup.repository.*
import org.junit.jupiter.api.AfterEach
import org.junit.jupiter.api.BeforeEach
import org.junit.jupiter.api.Test

import org.junit.jupiter.api.Assertions.*
import org.mockito.Mock
import org.mockito.MockitoAnnotations

class ExpenseServiceImplTest {

    @Mock
    private lateinit var  expenseRepository: ExpenseRepository
    @Mock
    private lateinit var userExpenseRepository: UserExpenseRepository
    @Mock
    private lateinit var userReceiveRepository: UserReceiveRepository
    @Mock
    private lateinit var groupRepository: GroupRepository
    @Mock
    private lateinit var groupMemberRepository: GroupMemberRepository
    @Mock
    private lateinit var userRepository: UserRepository
    @Mock
    private lateinit var expenseService: ExpenseServiceImpl

    @BeforeEach
    fun setUp() {
        MockitoAnnotations.initMocks(this)
        expenseService= ExpenseServiceImpl(expenseRepository,userExpenseRepository,userReceiveRepository,groupRepository,groupMemberRepository,userRepository)

    }


    @Test
    fun createExpense() {
        var req= ExpenseRequestDto(1,200,3,"party")
        var req1= UserExpenseEntity(1,2,200,2)
        var expected= ExpenseEntity(1,1,200,3,"party")



        whenever(expenseRepository.save(req.toEntityExpense())).thenReturn(req.toEntityExpense())
        whenever(groupMemberRepository.findAllByGroupId(1)).thenReturn(null)
        whenever(userExpenseRepository.save(req1)).thenReturn(null)




        assertThrows(Exception::class.java) {
            expenseService.createExpense(req)
        }



    }
}