import React, { createContext,useState} from 'react';
const  DataContext:any=createContext({})
export default DataContext