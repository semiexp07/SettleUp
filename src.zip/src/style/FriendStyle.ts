import React from 'react';

export const body: React.CSSProperties = {
  display: 'grid',
  gridTemplateColumns: '55% 45%',
  backgroundColor: '#0d0d0d',
};
export const grid1: React.CSSProperties = {
  display: 'flex',
  flexDirection: 'column',
  justifyContent: 'start',
  backgroundColor: '',
  height: '100vh',
  width: '100%',
  padding: '7px',
  borderLeft: '0.5px solid #f1f1f1',
  boxSizing: 'border-box',
};
export const grid2: React.CSSProperties = {
  backgroundColor: '#0d0d0d',
  height: '100%',
  width: '100%',
};
export const gridGayab: React.CSSProperties = {
  display: 'none',
};
export const flexFrndDashed: React.CSSProperties = {
  display: 'flex',
  justifyContent: 'space-between',
  alignItems: 'center',
  marginTop: '20px',
  padding: '10px',
  boxSizing: 'border-box',
};
export const yourFriendText: React.CSSProperties = {
  fontFamily: '"Roboto"',
  fontStyle: 'normal',
  fontWeight: 500,
  fontSize: 16,
  color: '#8A8A8A',
};
export const addFriendButton: React.CSSProperties = {
  background: '#161616',
  border: '0.5px solid #333333',
  height: 25,
  width: 25,
  borderRadius: '50%',
};
export const friendHeader: React.CSSProperties = {
  display: 'flex',
  flexDirection: 'column',
  marginTop: '15px',
};
export const expenseHistory: React.CSSProperties = {
  backgroundColor: '#0d0d0d',
  height: '65px',
  width: '100%',
  borderBottom: '0.1px solid rgba(47, 46, 46, 0.832)',
  display: 'flex',
  justifyContent: 'space-between',
  alignItems: 'center',
  flexDirection: 'row',
  padding: '5px',
  boxSizing: 'border-box',
};
export const flexTextImg: React.CSSProperties = {
  display: 'flex',
  alignItems: 'center',
};
export const flexImg: React.CSSProperties = { borderRadius: '50%' };
export const flexText: React.CSSProperties = {
  fontFamily: '"Roboto"',
  fontSize: 16,
  letterSpacing: '0.05em',
  textTransform: 'capitalize',
  color: '#8A8A8A',
};
export const flexAmount: React.CSSProperties = {
  fontFamily: '"Roboto"',
  fontStyle: 'normal',
  fontWeight: 500,
  fontSize: 16,
  lineHeight: 19,
  textTransform: 'uppercase',
  color: '#06C270',
};
export const crtBar: React.CSSProperties = {
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'space-between',
  height: '40px',
  width: '94%',
  background: 'linear-gradient(90.05deg, #1e8057 12.24%, #04c876 99.96%)',
  padding: '10px',
  margin: '5px',
};
export const crtBatText: React.CSSProperties = {
  fontFamily: '"Roboto"',
  fontStyle: 'normal',
  fontWeight: 500,
  fontSize: '10px',
  letterSpacing: '0.05em',
  textTransform: 'uppercase',
  color: '#fbfbfb',
  padding: '0px',
  margin: '0px',
};
export const crtBatAmount: React.CSSProperties = {
  width: 74,
  height: 28,
  fontFamily: '"Roboto"',
  fontStyle: 'normal',
  fontWeight: 600,
  fontSize: 18,
  textTransform: 'uppercase',
  color: '#fbfbfb',
  padding: '0px',
  margin: '0px',
};
export const crtBarButton: React.CSSProperties = {
  fontFamily: 'Roboto',
  fontSize: '13px',
  letterSpacing: '0.2px',
  color: '#0D0D0D',
  height: '30px',
  width: '80px',
  border: '0px',
  padding: '0px',
  margin: '0px',
};

export const month: React.CSSProperties = {
  display: 'flex',
  flexDirection: 'column',
  justifyContent: 'space-around',
  padding: '0px',
  margin: '0px',
};
export const monthTextBar: React.CSSProperties = {
  fontFamily: 'Roboto',
  fontSize: '12px',
  letterSpacing: '2px',
  textTransform: 'uppercase',
  color: '#8A8A8A',
  paddingLeft: '20px',
  margin: '0px',
};
export const expenseHistoryCard: React.CSSProperties = {
  backgroundColor: '#121212',
  height: '45px',
  display: 'flex',
  justifyContent: 'start',
  alignItems: 'center',
  padding: '20px',
  margin: '0px',
};
export const date: React.CSSProperties = {
  display: 'flex',
  flexDirection: 'column',
  alignItems: 'center',
  height: '100%',
  width: '40px',
};
export const details: React.CSSProperties = {
  backgroundColor: '#121212',
  display: 'flex',
  flexDirection: 'column',
  width: '350px',
  height: '40px',
  marginLeft: '20px',
  padding: '3px',
  justifyContent: 'space-evenly',
};
export const rupee: React.CSSProperties = {
  display: 'flex',
  justifyContent: 'end',
  alignItems: 'center',
  width: '100px',
  padding: '0px',
  margin: '0px',
};
export const nameLoc: React.CSSProperties = {
  marginTop: '5px',
  display: 'flex',
  alignItems: 'center',
  padding: '0px',
};
export const dateText: React.CSSProperties = {
  color: '#FFFFFF',
  fontSize: 10,
  fontFamily: '"Roboto"',
  padding: '3px',
  margin: '0px',
};
export const headingText: React.CSSProperties = {
  color: '#D2D2D2',
  fontSize: 10,
  fontFamily: '"Roboto"',
  letterSpacing: '0.2px',
  padding: '0px',
  margin: '0px',
};
export const nameLocation: React.CSSProperties = {
  fontFamily: '"Roboto"',
  fontSize: 10,
  letterSpacing: '0.05em',
  textTransform: 'capitalize',
  color: '#8A8A8A',
  padding: '0px',
  margin: '0px',
};
export const amountPending: React.CSSProperties = {
  fontFamily: '"Roboto"',
  fontStyle: 'normal',
  fontWeight: 500,
  fontSize: 16,
  textTransform: 'uppercase',
  color: '#F05E4B',
  padding: '0px',
  margin: '0px',
};
