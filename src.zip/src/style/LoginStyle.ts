import React from 'react';

export const body: React.CSSProperties = {
  display: 'flex',
  justifyContent: 'space-around',
  backgroundColor: '#91bf99',
  alignItems: 'center',
  height: '400px',
  margin: '120px ',
};
export const login: React.CSSProperties = {
  display: 'flex',
  justifyContent: 'center',
  flexDirection: 'column',
  alignItems: 'start',
  backgroundColor: '#000000',
  width: '55%',
  height: '100%',
  paddingLeft: '17%',
};

export const heading: React.CSSProperties = {
  fontSize: '27px',
  fontFamily: 'roboto',
  color: '#FFFFFF',
};
export const lebel: React.CSSProperties = {
  color: '#8A8A8A',
  fontSize: '9px',
  fontFamily: 'roboto',
  letterSpacing: '1px',
};
export const input: React.CSSProperties = {
  height: '25px',
  width: '250px',
  color: '#f1f1f1',
  fontSize: '9px',
  backgroundColor: '#161616',
  border: '0.5px solid #3D3D3D',
  paddingLeft: '5px',
};

export const buttonLogin: React.CSSProperties = {
  height: '35px',
  width: '258px',
  fontSize: '12px',
  fontFamily: 'roboto',
  fontWeight: '900',
  letterSpacing: '1px',
  padding: '5px',
  border: '0.5px solid #3D3D3D',
  backgroundColor: '#D2D2D2',
};

export const signUp: React.CSSProperties = {
  display: 'flex',
  backgroundColor: '#161616',
  flexDirection: 'column',
  justifyContent: 'center',
  alignItems: 'start',
  width: '45%',
  height: '100%',
  paddingLeft: '5%',
};

export const createHeading: React.CSSProperties = {
  color: '#8A8A8A',
  fontFamily: 'roboto',
  letterSpacing: '1px',
};
