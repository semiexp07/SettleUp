import React from 'react';

export const bodyDashboard: React.CSSProperties = {
  display: 'grid',
  gridTemplateColumns: '6% 94%',
  position: 'relative',
  top: '0px',
  backgroundColor: '#0D0D0D',
};

export const flexContainer: React.CSSProperties = {
  display: 'flex',
  flexDirection: 'column',
  justifyContent: 'center',
  height: '100vh',
  width: '100%',
  backgroundColor: '#0D0D0D',
};

export const option: React.CSSProperties = {
  display: 'flex',
  flexDirection: 'column',
  justifyContent: 'center',
  alignItems: 'center',
  width: '100%',
  height: '10%',
  background: '#0D0D0D',
  borderBottom: '0.5px solid #3b3a3abd',
  padding: '0px',
};
export const imgText: React.CSSProperties = {
  color: '#8A8A8A',
  fontSize: '12px',
  fontFamily: 'roboto',
  margin: '0px',
  padding: '0px',
};
