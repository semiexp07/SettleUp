import { padding } from './AddExpense';
import { borderLeft } from './HomeStyle';

export const body: React.CSSProperties = {
  backgroundColor: '#0d0d0d',
  height: '100vh',
  overflow: 'scroll',
};
export const marginLena: React.CSSProperties = {
  margin: '20px',
};

export const card: React.CSSProperties = {
  backgroundColor: '#161616',
  display: 'flex',
  flexDirection: 'column',
  margin: '20px',
  overflow: 'scroll',
};
export const cardBody: React.CSSProperties = {
  display: 'flex',
  flexDirection: 'column',
  borderBottom: '0.5 solid #f13f4f',
  justifyContent: 'center',
  alignItems: 'center',
};
export const share: React.CSSProperties = {
  margin: '5px',
  backgroundColor: '#0d0d0d',
  display: 'flex',
  justifyContent: 'space-around',
  alignItems: 'center',
  borderRadius: '50px',
  borderBottom: '0.5 solid #f13f4f',
  padding: '5px',
  width: '70%',
};
export const buttonRequest: React.CSSProperties = {
  backgroundColor: '#0d0d0d',
  width: '100px',
  alignItems: 'center',
  borderRadius: '50px',
  border: '0px',
  padding: '5px',
  color: '#f1f1f1',
};
export const bodyTitle: React.CSSProperties = {
  display: 'flex',
  justifyContent: 'space-between',
  alignItems: 'center',
  width: '90%',
};
export const title: React.CSSProperties = {
  color: '#f3f3f3',
};

export const marginLo: React.CSSProperties = {
  marginRight: '50px',
};
