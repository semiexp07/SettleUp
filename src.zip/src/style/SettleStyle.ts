const SettleStyle = () => {
  return 1;
};
export default SettleStyle;
