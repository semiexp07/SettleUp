import React from 'react';
import { padding } from './AddExpense';

export const body: React.CSSProperties = {
  display: 'grid',
  gridTemplateColumns: '68% 29%',
  padding: '0px',
  margin: '0px',
  boxSizing: 'border-box',
  borderLeft: '0.5px solid #3b3a3abd',
  borderRight: '1px solid #f3f3f3',
  backgroundColor: '#0d0d0d',
};
export const imageText: React.CSSProperties = {
  display: 'flex',
  justifyContent: ' flex-end',
  alignItems: 'center',
  fontFamily: 'Roboto',
};
export const circleImage: React.CSSProperties = {
  borderRadius: '50%',
};
export const header: React.CSSProperties = {
  display: 'flex',
  flexDirection: 'column',
  height: '200px',
  width: '100%',
  backgroundColor: '#161616',
  boxSizing: 'border-box',
  padding: '1%',
};
//   leftBody
export const leftBody: React.CSSProperties = {
  display: 'flex',
  flexDirection: 'column',
  height: '100%',
  width: '100%',
  backgroundColor: '#121212',
  boxSizing: 'border-box',
};
export const headerMain: React.CSSProperties = {
  display: 'flex',
  justifyContent: 'space-between',
  alignItems: 'center',
  height: '30%',
  width: '100%',
  backgroundColor: '#161616',
  paddingLeft: '10px',
  paddingRight: '10px',
  boxSizing: 'border-box',
};
export const headerMain2: React.CSSProperties = {
  display: 'flex',
  justifyContent: 'space-between',
  alignItems: 'center',
  height: '30%',
  width: '100%',
  backgroundColor: '#161616',
  boxSizing: 'border-box',
  paddingLeft: '10px',
  paddingRight: '10px',
};
export const searchButton: React.CSSProperties = {
  height: '30px',
  width: '30px',
  borderRadius: '50%',
  padding: '0px',
  margin: '0px',
  border: '0.5px solid #d1d1d1',
  marginRight: '10px',
  backgroundColor: '#161616',
};
export const searchButtonImage: React.CSSProperties = {
  height: '30px',
  width: '30px',
  borderRadius: '50%',
  padding: '0px',
  margin: '0px',
  backgroundColor: '#161616',
};

export const addFriend: React.CSSProperties = {
  display: 'flex',
  justifyContent: 'center',
  height: '30px',
  width: '100px',
  borderRadius: '50px',
  padding: '0px',
  margin: '0px',
  border: '0.5px solid #d1d1d1',
  marginLeft: '5px',
  backgroundColor: '#161616',
  alignItems: 'center',
  textAlign: 'center',
};
export const searchAddFriend: React.CSSProperties = {
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'end',
};
export const addFriendText: React.CSSProperties = {
  font: '10px',
  fontFamily: 'roboto',
  color: '#f1f1f1',
  margin: '2px',
};
export const imageAddFriend: React.CSSProperties = {
  height: '20px',
  width: '20px',
  borderRadius: '50%',
  padding: '0px',
  margin: '0px',
  backgroundColor: '#161616',
};
export const receivePay: React.CSSProperties = {
  display: 'flex',
  justifyContent: 'center',
  marginTop: '15px',
};
export const receive: React.CSSProperties = {
  display: 'flex',
  flexDirection: 'column',
  alignItems: 'start',
  justifyContent: 'center',
  height: '50px',
  width: '400px',
  background: 'linear-gradient(90.05deg, #1e8057 12.24%, #04c876 99.96%)',
  padding: '10px',
  margin: '0px',
};
export const pay: React.CSSProperties = {
  height: '50px',
  width: '300px',
  display: 'flex',
  flexDirection: 'column',
  alignItems: 'end',
  justifyContent: 'center',
  background: 'linear-gradient(270deg, #ee4d37 50.1%, #f56c59 100%)',
  padding: '10px',
  margin: '0px',
};

export const receiveText: React.CSSProperties = {
  fontFamily: 'roboto',
  fontStyle: 'normal',
  fontWeight: 500,
  fontSize: 10,
  letterSpacing: '0.05em',
  textTransform: 'uppercase',
  color: '#fbfbfb',
  margin: '0px',
};
export const receiveAmount: React.CSSProperties = {
  width: 74,
  height: 28,
  fontFamily: 'roboto',
  fontStyle: 'normal',
  fontWeight: 600,
  fontSize: 18,
  textTransform: 'uppercase',
  color: '#fbfbfb',
  margin: '0px',
};
export const payText: React.CSSProperties = {
  fontFamily: '"roboto"',
  fontStyle: 'normal',
  fontWeight: 500,
  fontSize: 10,
  letterSpacing: '0.05em',
  textTransform: 'uppercase',
  color: '#f1f1f1',
  margin: '0px',
};
export const payAmount: React.CSSProperties = {
  width: 74,
  height: 28,
  fontFamily: '"Roboto"',
  fontStyle: 'normal',
  fontWeight: 700,
  fontSize: 18,
  textTransform: 'uppercase',
  textAlign: 'right',
  textAlignLast: 'right',
  color: '#fbfbfb',
  margin: '0px',
};
export const netWorthContainer: React.CSSProperties = {
  display: 'flex',
  justifyContent: 'space-between',
  alignItems: 'center',
  height: '30px',
  width: '740px',
  marginTop: '10px',
  padding: '7px 10px',
  background: '#161616',
  border: '0.5px solid #333333',
  boxSizing: 'border-box',
  marginLeft: '2px',
};
export const box: React.CSSProperties = {
  backgroundColor: '#1f8058',
  height: '8px',
  width: ' 8px',
  display: 'inline-block',
  marginRight: '5px',
  marginTop: '2px',
  boxSizing: 'border-box',
};
export const netWorthContainerBox: React.CSSProperties = {
  display: 'flex',
  marginTop: 5,
  boxSizing: 'border-box',
};
export const netWorth: React.CSSProperties = {
  color: '#fbfbfb',
  fontSize: 10,
  fontFamily: '"Roboto"',
  fontStyle: 'normal',
  boxSizing: 'border-box',
};
export const netWorthAmount: React.CSSProperties = {
  fontFamily: '"Roboto"',
  fontStyle: 'normal',
  fontWeight: 700,
  fontSize: 14,
  textTransform: 'uppercase',
  color: '#d2d2d2',
  boxSizing: 'border-box',
};
export const urfrnd: React.CSSProperties = {
  display: 'flex',
  justifyContent: 'space-between',
  padding: '10px ',
  backgroundColor: '#0d0d0d',

  height: '30px',
};
export const urfrndText: React.CSSProperties = {
  color: '#8a8a8a',
  fontSize: 14,
  fontFamily: '"Roboto"',
};
export const urfrndViewAll: React.CSSProperties = {
  color: '#d2d2d2',
  textDecoration: 'underline',
  fontSize: 10,
};
export const name: React.CSSProperties = {
  marginLeft: 5,
  fontSize: 14,
  color: '#d2d2d2',
};
export const transectionInside: React.CSSProperties = {
  backgroundColor: '#121212',
  padding: 5,
  height: 40,
  border: '0.5px solid #333333',
  marginRight: 2,
};
export const transectionText: React.CSSProperties = {
  fontFamily: 'roboto',
  fontStyle: 'normal',
  fontWeight: 500,
  fontSize: 8,
  letterSpacing: '0.03em',
  textTransform: 'uppercase',
  color: '#d2d2d2',
};
export const transectionAmount: React.CSSProperties = {
  width: 74,
  height: 25,
  fontFamily: 'roboto',
  fontStyle: 'normal',
  fontWeight: 600,
  fontSize: 12,
  textTransform: 'uppercase',
  color: '#06c270',
  margin: '0px',
};
export const friendRequest: React.CSSProperties = {
  borderWidth: '0px',
  height: '100%',
  width: '100%',
  fontSize: '12px',
  fontFamily: 'roboto',
};
export const transection: React.CSSProperties = {
  display: 'grid',
  gridTemplateColumns: '65% 35%',
  marginTop: '5px',
};
export const yourFriend: React.CSSProperties = {
  width: '220px',
  backgroundColor: '#161616',
  marginBottom: '10px',
  padding: '10px',
};
export const itemCenter: React.CSSProperties = {
  display: 'flex',
  alignItems: 'center',
  padding: '5px 0px',
};
export const pendingPay: React.CSSProperties = {
  display: 'flex',
  flexWrap: 'wrap',
  justifyContent: 'space-evenly',
  background: '#0d0d0d',
};
export const grpCard: React.CSSProperties = {
  width: '230px',
  backgroundColor: '#161616',
  padding: '5px',
  marginBottom: '10px',
};
export const flatmates: React.CSSProperties = {
  color: '#fbfbfb',
  paddingLeft: 5,
  margin: '0px',
};
export const image: React.CSSProperties = {
  position: 'relative',
};
export const image1: React.CSSProperties = {
  marginTop: '5px',
  marginLeft: '0px',
  position: 'absolute',
};
export const image2: React.CSSProperties = {
  marginTop: '5px',
  marginLeft: '0px',
  position: 'absolute',
  left: '10px',
};
export const image3: React.CSSProperties = {
  marginTop: '5px',
  marginLeft: '0px',
  position: 'absolute',
  left: '20px',
};
export const image4: React.CSSProperties = {
  marginTop: '5px',
  marginLeft: '0px',
  position: 'absolute',
  left: '30px',
};
export const image5: React.CSSProperties = {
  marginTop: '5px',
  marginLeft: '0px',
  left: '40px',
  position: 'relative',
  marginBottom: '5px',
};
export const requestPay: React.CSSProperties = {
  display: 'flex',
  justifyContent: 'space-evenly',
  backgroundColor: '#161616',
  width: '100%',
};
export const reqPay: React.CSSProperties = {
  height: '40px',
  width: '100px',
  margin: '2px',
  padding: '6px 2px',
};
export const rePayText: React.CSSProperties = {
  fontFamily: 'roboto',
  fontSize: 8,
  letterSpacing: 2,
  textTransform: 'uppercase',
  color: 'rgba(255, 255, 255, 0.5)',
};
export const shareMoney: React.CSSProperties = {
  fontFamily: 'roboto',
  fontStyle: 'normal',
  fontWeight: 400,
  fontSize: 12,
  textTransform: 'uppercase',
  color: '#d2d2d2',
};
export const py: React.CSSProperties = {
  height: '40px',
  width: '100px',
  margin: '2px',
  border: '0.5px solid rgb(58, 58, 58)',
  padding: '6px 5px',
};
export const youPay: React.CSSProperties = {
  fontFamily: 'roboto',
  fontSize: 8,
  letterSpacing: 2,
  textTransform: 'uppercase',
  color: 'rgba(255, 255, 255, 0.5)',
};
export const youPayAmount: React.CSSProperties = {
  fontFamily: 'roboto',
  fontStyle: 'normal',
  fontWeight: 500,
  fontSize: 12,
  textTransform: 'uppercase',
  color: '#f05e4b',
  flex: 'none',
  order: 1,
};
export const flexGroup: React.CSSProperties = {
  display: 'flex',
  justifyContent: 'space-evenly',
  alignItems: 'start',
  flexWrap: 'wrap',
  padding: '1px',
  backgroundColor: '#0D0D0D',
};
export const recent: React.CSSProperties = {
  fontFamily: 'roboto',
  fontSize: '14px',
  lineHeight: '16px',
  letterSpacing: '2px',
  textTransform: 'uppercase',
  marginTop: '18px',
  color: '#8A8A8A',
};
export const flexRightBoxRecent: React.CSSProperties = {
  height: '70px',
  width: '100%',
};
export const flexRightBox: React.CSSProperties = {
  height: '50px',
  width: '100%',
  borderBottom: '0.1px solid #3b3a3abd',
  borderWidth: '0.5px',
  marginLeft: '5px',
};
export const text: React.CSSProperties = {
  color: '#8A8A8A',
  marginLeft: '10px',
};
export const flexRightBoxProfile: React.CSSProperties = {
  height: '50px',
  width: '100%',
  borderBottom: '0.1px solid #3b3a3abd',
  borderWidth: '0.5px',
};
export const flexHistoryProfile: React.CSSProperties = {
  display: 'flex',
  justifyContent: 'space-around',
  alignItems: 'center',
  backgroundColor: '#0d0d0d',
  width: '100%',
  height: '100%',
};
export const flexHistoryProfileImage: React.CSSProperties = {
  padding: '5px',
  backgroundColor: '#1e1e1e',
};
export const flexHPSecond: React.CSSProperties = {
  display: 'flex',
  flexDirection: 'column',
  justifyContent: 'space-evenly',
  alignItems: 'start',
};
export const flexHPImage: React.CSSProperties = {
  fontFamily: 'roboto',
  fontSize: '12px',
  letterSpacing: '0.2px',
  alignItems: 'self-start',
  color: '#D2D2D2',
  margin: '0px',
};
export const imgText2: React.CSSProperties = {
  display: 'flex',
  justifyContent: 'center',
  alignItems: 'center',
  fontFamily: 'roboto',
  marginTop: '7px',
};
export const nameHistory: React.CSSProperties = {
  fontFamily: 'roboto',
  fontSize: '12px',
  alignItems: 'baseline',
  letterSpacing: '0.2px',
  color: '#8A8A8A',
  margin: '0px',
  padding: '0px',
};
export const dateTimeMoney: React.CSSProperties = {
  display: 'flex',
  flexDirection: 'column',
  justifyContent: 'space-around',
  alignItems: 'end',
};
export const dateTimeMoneyAmount: React.CSSProperties = {
  fontFamily: 'roboto',
  fontStyle: 'normal',
  fontWeight: '500',
  fontSize: '12px',
  textTransform: 'uppercase',
  color: '#F05E4B',
  margin: '0px',
};
export const dateTime: React.CSSProperties = {
  fontFamily: 'roboto',
  fontSize: '10px',
  textAlign: 'center',
  textTransform: 'uppercase',
  color: 'rgba(255, 255, 255, 0.5)',
};
export const borderLeft: React.CSSProperties = {
  borderLeft: '0.5 solid #3b3a3abd',
};
