import React from 'react';

export const prt: React.CSSProperties = {
  display: 'flex',
  justifyContent: 'center',
  alignItems: 'center',
  width: '100%',
  height: '550px',
};
export const body: React.CSSProperties = {
  display: 'flex',
  justifyContent: 'center',
  width: '300px',
  height: '450px',
  backgroundColor: ' #121212',
};
export const mainPopScreen: React.CSSProperties = {
  display: 'flex',
  justifyContent: 'start',
  flexDirection: 'column',
  width: '100%',
  height: '60%',
  padding: ' 6%',
};

export const popHeader: React.CSSProperties = {
  display: 'flex',
  justifyContent: 'space-between',
  alignItems: 'center',
  borderBottom: ' 0.1px solid rgba(51, 51, 51, 0.818)',
  width: '100%',
  height: '25%',
};
export const tAmt: React.CSSProperties = {
  display: 'flex',
  flexDirection: 'column',
  justifyContent: 'center',
  padding: '0px',
  margin: '0px',
};
export const imgQues: React.CSSProperties = {
  display: 'flex',
  alignItems: 'center',
  width: '90%',
  height: '50px',
  marginLeft: '10px',
};
export const ques: React.CSSProperties = {
  width: '100%',
  height: '20px',
  backgroundColor: ' #161616',
  border: '0.1px solid rgb(77, 77, 77)',
  justifyContent: 'center',
  alignItems: 'center',
};

export const input1: React.CSSProperties = {
  display: 'flex',
  flexDirection: 'column',
  marginLeft: '10px',
};
export const inputBox: React.CSSProperties = {
  width: '90%',
  height: '20px',
  backgroundColor: '#161616',
  border: '0.1px solid rgb(77, 77, 77)',
  justifyContent: 'center',
  marginLeft: '10px',
};
export const todayGroup: React.CSSProperties = {
  display: 'flex',
  justifyContent: 'start',
  alignItems: 'center',
  height: '40px',
  paddingLeft: '10px',
};
export const tdyGrp: React.CSSProperties = {
  width: '80px',
  height: '100%',
  backgroundColor: '#161616',
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
  border: '0.1px solid #474545d5',
  marginRight: '5px',
};
export const saveExp: React.CSSProperties = {
  height: '40px',
  width: '90%',
  marginLeft: '5%',
  border: '0px',
  display: 'flex',
  justifyContent: 'center',
  alignItems: 'center',
};
export const total1: React.CSSProperties = {
  fontSize: '15px',
  fontFamily: 'Roboto',
  color: 'azure',
};
export const total2: React.CSSProperties = {
  fontSize: '15px',
  fontFamily: 'Roboto',
  color: ' azure',
};
export const sqImg: React.CSSProperties = {
  backgroundColor: '#161616',
  height: '40px',
  width: '40px',
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
};
export const saveExpense: React.CSSProperties = {
  fontFamily: '"Roboto"',
  fontSize: '14px',
  display: 'flex',
  alignItems: 'center',
  letterSpacing: '0.2px',
  color: '#0D0D0D',
};
export const groupInfo: React.CSSProperties = {
  color: '#D2D2D2',
  fontFamily: '"Roboto"',
  fontWeight: '500',
  fontSize: '15px',
  paddingLeft: '5px',
};
export const today: React.CSSProperties = {
  color: '#D2D2D2',
  fontFamily: '"Roboto"',
  fontWeight: '500',
  fontSize: '15px',
  paddingLeft: '5px',
};
export const add: React.CSSProperties = {
  color: '#D2D2D2',
  padding: '15px',
  fontSize: '8px',
};
export const inputText: React.CSSProperties = {
  color: '#8A8A8A',
  paddingLeft: '10px',
  paddingBottom: '5px',
  fontSize: '8px',
};
export const inputBoxText: React.CSSProperties = {
  color: '#D2D2D2',
  padding: '15px',
  fontSize: '8px',
};
export const splitBetween: React.CSSProperties = {
  color: '#8A8A8A',
  paddingLeft: '10px',
  paddingBottom: '5px',
  fontSize: '8px',
};
export const questionText: React.CSSProperties = {
  color: '#3D3D3D',
  padding: '8px',
  fontSize: '8px',
};
export const amount: React.CSSProperties = {
  fontSize: '15px',
  fontWeight: '700',
  color: '#D2D2D2',

  backgroundColor: '#161616',
  border: '0px',
};

export const padding: React.CSSProperties = { padding: '10px' };
