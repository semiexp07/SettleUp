import React, { createContext, useEffect, useState } from 'react';
import './App.css';
import { Routes, Route, useNavigate } from 'react-router-dom';
import Layout from './pages/Layout';
import Login from './pages/Login';

interface User {
  id: number;
  name: string;
  email: string;
  phone: string;
}
interface UserData {
  token: string;
  user: User;
}

export const UserData: any = createContext({});

function App() {
  const path = window.location.pathname;

  const nevigate = useNavigate();

  const isLoggedIn = localStorage.getItem('token');
  const [user, setUser] = useState<any>();

  useEffect(() => {
    if (path !== '/login' && !isLoggedIn) {
      nevigate('/login');
    }
  }, [path]);

  return (
    <UserData.Provider value={{ user, setUser }}>
      <Routes>
        <Route path="login" index element={<Login />} />
        <Route path="/dashboard" element={<Layout />} />
      </Routes>
    </UserData.Provider>
  );
}

export default App;
