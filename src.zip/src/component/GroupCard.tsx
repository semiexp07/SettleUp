import {
  grpCard,
  flatmates,
  image,
  friendRequest,
  circleImage,
  name,
  transectionInside,
  transectionText,
  transectionAmount,
  image1,
  image2,
  image3,
  image4,
  image5,
  requestPay,
  reqPay,
  rePayText,
  shareMoney,
  py,
  youPay,
  youPayAmount,
} from '../style/HomeStyle';
import one from '../assets/one.png';
import gone from '../assets/gone.png';
import gtwo from '../assets/gtwo.png';
import gthree from '../assets/gthree.png';
import gfour from '../assets/gfour.png';
import gfive from '../assets/gfive.png';
import { useBalance } from '../hook/useBalance';
interface Prop {
  description: string;
  friends: { balance: number; id: number; name: string }[];
  id: number;
  name: string;
}
const GroupCard = (prop: Prop) => {
  const { description, friends, id, name } = prop;

  let total = 0;
  let myTotal = 0;
  const userid = localStorage.getItem('id') as any;
  friends.map((obj) => {
    total += obj.balance;
    if (obj.id == userid) {
      myTotal += obj.balance;
    }
  });

  return (
    <>
      <div style={grpCard}>
        <p style={flatmates}>{name}</p>
        <div style={image}>
          <img style={image1} src={gone} height="30px" width="30px" />
          <img style={image2} src={gtwo} height="30px" width="30px" />
          <img style={image3} src={gthree} height="30px" width="30px" />
          <img style={image4} src={gfour} height="30px" width="30px" />
          <img style={image5} src={gfive} height="30px" width="30px" />
        </div>
        <div style={requestPay}>
          <div style={reqPay}>
            <p style={rePayText}>Your share</p>
            <p style={shareMoney}>
              ₹ {myTotal} / {total}
            </p>
          </div>
          <div style={py}>
            <p style={youPay}>you pay</p>
            <p style={youPayAmount}>₹ {myTotal}</p>
          </div>
        </div>
      </div>
    </>
  );
};
export default GroupCard;
