import { bodyTitle, marginLo, title } from '../style/GroupStyle';
import { sqImg } from '../style/AddExpense';
import { amountPending, rupee } from '../style/FriendStyle';

import img1 from '../assets/netflix.png';

const GroupCardTitle = (prop: any) => {
  const { name, total } = prop;
  return (
    <div style={bodyTitle}>
      <div style={marginLo}>
        <div style={sqImg}>
          <img src={img1} height="20px" width="20px" />
        </div>
      </div>
      <div>
        <p style={title}>{name}</p>
      </div>
      <div style={rupee}>
        <p style={amountPending}>₹{total}</p>
      </div>
    </div>
  );
};
export default GroupCardTitle;
