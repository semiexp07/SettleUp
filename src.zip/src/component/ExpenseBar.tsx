import {
  receivePay,
  receive,
  pay,
  receiveText,
  receiveAmount,
  payText,
  payAmount,
} from '../style/HomeStyle';

interface Prop {
  amountToReceive: number;
  amountToPay: number;
}
const ExpenseBar = (prop: any) => {
  const { amountToReceive, amountToPay } = prop;

  return (
    <>
      <div style={receivePay}>
        <div style={receive}>
          <div>
            <p style={receiveText}>Receive</p>
          </div>
          <div>
            <p style={receiveAmount}>₹ {amountToReceive}</p>
          </div>
        </div>
        <div style={pay}>
          <div>
            <p style={payText}>Pay</p>
          </div>
          <div>
            <p style={payAmount}>₹ {amountToPay}</p>
          </div>
        </div>
      </div>
    </>
  );
};
export default ExpenseBar;
