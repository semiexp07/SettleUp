import { card, cardBody } from '../style/GroupStyle';
import YourFriendTitle from './YourFriendTitle';
import Share from './Share';
import GroupCardTitle from './GroupCardTitle';
interface Prop {
  description: any;
  friends: { balance: number; id: number; name: string }[];
  id: number;
  name: string;
}
interface Title {
  name: string;
  total: number;
}

const GroupDetailCard = (prop: Prop) => {
  const { description, friends, id, name } = prop;
  let total = 0;
  friends.map((o) => {
    total += Math.abs(o.balance);
  });
  const data: Title = { name, total };

  return (
    <div style={card}>
      <div style={cardBody}>
        <GroupCardTitle {...data} />
        {!!friends && (
          <div>
            {friends.map((obj) => {
              return <Share key={'user' + obj.id} {...obj} />;
            })}
          </div>
        )}
      </div>
    </div>
  );
};
export default GroupDetailCard;
