import { amountPending, crtBarButton, rupee } from '../style/FriendStyle';
import { share, buttonRequest } from '../style/GroupStyle';
import ImageName from './ImageName';
interface Prop {
  balance: number;
  id: number;
  name: string;
}

const Share = (prop: Prop) => {
  const { balance, id, name } = prop;
  return (
    <div style={share}>
      <ImageName />
      <div style={rupee}>
        <p style={amountPending}>₹{balance}</p>
      </div>
      <button style={buttonRequest}>
        <p>Request</p>
      </button>
    </div>
  );
};
export default Share;
