import { searchButton, searchButtonImage } from "../style/HomeStyle"
import search from "../assets/threedot.svg"


const ThreeDot=()=>{
    return (
        <>
        <div >
              <button style={searchButton}> 
                <img src={search}  style={searchButtonImage}/>
              </button>
        </div>
        </>
    )
}
export default ThreeDot