import { imageAddFriend, addFriend, addFriendText } from '../style/HomeStyle';
import frndadd from '../assets/frndadd.svg';

const AddFriend = () => {
  return (
    <>
      <div>
        <button style={addFriend}>
          <img src={frndadd} style={imageAddFriend} />
          <p style={addFriendText}>Add Friend</p>
        </button>
      </div>
    </>
  );
};
export default AddFriend;
