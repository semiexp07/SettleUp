import { useContext, useState } from 'react';
import useLoginUser from '../hook/useLoginUser';
import { buttonLogin, input, login } from '../style/LoginStyle';
import { heading } from '../style/LoginStyle';
import { lebel } from '../style/LoginStyle';
import { useNavigate } from 'react-router-dom';
import { UserData } from '../App';

export type CreadentialLogin = {
  email: string;
  password: string;
};
const LoginPart = () => {
  const nevigate = useNavigate();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const { user, setUser } = useContext(UserData) as any;

  const onClick = () => {
    const credential: CreadentialLogin = {
      email: email,
      password: password,
    };
    useLoginUser(credential, setUser);
    if (localStorage.length != 0) {
      nevigate('/dashboard');
    }
  };

  return (
    <div style={login}>
      <div>
        <p style={heading}>Welcome to SettleUp</p>
      </div>

      <div>
        <label style={lebel}>EMAIL ID *</label>
        <br />
        <input
          style={input}
          placeholder="abc@gmail.com"
          onChange={(e) => setEmail(e.target.value)}
        ></input>
        <br />
        <label style={lebel}>PASSWORD *</label>
        <br />
        <input
          style={input}
          placeholder="XXX"
          onChange={(e) => setPassword(e.target.value)}
        ></input>
      </div>
      <br />
      <div>
        <button style={buttonLogin} onClick={onClick}>
          Login
        </button>
      </div>
    </div>
  );
};

export default LoginPart;
