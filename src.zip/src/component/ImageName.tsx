import { imageText, circleImage, text } from '../style/HomeStyle';
import profiletop from '../assets/profiletop.png';
import { useState } from 'react';

const ImageName = () => {
  const userData = localStorage.getItem('token');
  const username = 'Welcome, ' + localStorage.getItem('name');
  return (
    <>
      <div style={imageText}>
        <div>
          <img src={profiletop} height="35px" width="35px" style={circleImage} />
        </div>
        <div>
          <p style={text}>{username}</p>
        </div>
      </div>
    </>
  );
};
export default ImageName;
