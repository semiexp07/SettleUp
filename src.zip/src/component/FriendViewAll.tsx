import { urfrnd, urfrndText, urfrndViewAll } from '../style/HomeStyle';

const FriendViewAll = () => {
  return (
    <div style={urfrnd}>
      <p style={urfrndText}>Your friends</p>
      <h6 style={urfrndViewAll}>view all</h6>
    </div>
  );
};
export default FriendViewAll;
