import { flexFrndDashed, yourFriendText, addFriendButton } from '../style/FriendStyle';
import friends from '../assets/frndadd.svg';

const YourFriendTitle = () => {
  return (
    
      <div style={flexFrndDashed}>
        <div>
          <p style={yourFriendText}> Your Friends</p>
        </div>
        <div>
            <button style={addFriendButton}>
               <img src={friends} height="20px" width="20px" />
            </button>
        </div>
      </div>
  );
};
export default YourFriendTitle;
