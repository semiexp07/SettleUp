import {
  itemCenter,
  yourFriend,
  transection,
  friendRequest,
  circleImage,
  name as nameStyle,
  transectionInside,
  transectionText,
  transectionAmount,
} from '../style/HomeStyle';
import one from '../assets/one.png';

const FriendCard = (prop: { id: number; name: string; balance: number }) => {
  const { id, name, balance } = prop;

  return (
    <div style={yourFriend}>
      <div style={itemCenter}>
        <div>
          <img src={one} height="35px" width="35px" style={circleImage} />
        </div>
        <div>
          <p style={nameStyle}>{name}</p>
        </div>
      </div>
      <div style={transection}>
        <div style={transectionInside}>
          <div>
            <div>
              <p style={transectionText}>You Receive</p>
            </div>
            <div>
              <p style={transectionAmount}>₹{balance}</p>
            </div>
          </div>
        </div>
        <div>
          <button style={friendRequest}>{balance < 0 ? 'Pay' : 'Receive'}</button>
        </div>
      </div>
    </div>
  );
};
export default FriendCard;
