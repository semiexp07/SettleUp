import {
  box,
  netWorthAmount,
  netWorth,
  netWorthContainer,
  netWorthContainerBox,
} from '../style/HomeStyle';

const NetWorthBar = (prop: any) => {
  const { amountToReceive, amountToPay } = prop;

  const total = amountToReceive - amountToPay;
  return (
    <>
      <div style={netWorthContainer}>
        <div style={netWorthContainerBox}>
          <span style={box} />
          <span style={netWorth}>NET {total >= 0 ? 'RECEIVABLE' : 'PAYABLE'}</span>
        </div>
        <div>
          <p style={netWorthAmount}>₹ {Math.abs(total)}</p>
        </div>
      </div>
    </>
  );
};
export default NetWorthBar;
