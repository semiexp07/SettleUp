import { expenseHistory, flexImg, flexTextImg, flexText, flexAmount } from '../style/FriendStyle';
import one from '../assets/one.png';
interface Prop {
  id: number;
  name: string;
  balance: number;
}
const FriendExpenseCard = (prop: Prop) => {
  const { id, name, balance } = prop;
  return (
    <div style={expenseHistory}>
      <div>
        <div style={flexTextImg}>
          <div style={flexImg}>
            <img src={one} height="40px" width="40px" />
          </div>
          <div>
            <p style={flexText}>{name}</p>
          </div>
        </div>
      </div>
      <div>
        <p style={flexAmount}>+ ₹ {balance}</p>
      </div>
    </div>
  );
};
export default FriendExpenseCard;
