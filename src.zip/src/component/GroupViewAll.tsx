import { urfrnd, urfrndText, urfrndViewAll } from '../style/HomeStyle';

const GroupViewAll = () => {
  return (
    <div style={urfrnd}>
      <p style={urfrndText}>Your groups</p>
      <h6 style={urfrndViewAll}>view all</h6>
    </div>
  );
};
export default GroupViewAll;
