import {
  flexRightBoxProfile,
  flexHistoryProfile,
  flexHistoryProfileImage,
  flexHPSecond,
  flexHPImage,
  imgText2,
  circleImage,
  nameHistory,
  dateTimeMoney,
  dateTimeMoneyAmount,
  dateTime,
} from '../style/HomeStyle';
import zomato from '../assets/zomato.png';
import one from '../assets/one.png';
interface Prop {
  amount: number;
  expenseCategory: string;
  expenseLabel: string;
  group: {
    description: string;
    id: number;
    name: string;
    users: { id: number; name: string; email: string; phone: string }[];
  }[];
  paidBy: { id: number; name: string; email: string; phone: string };
  peopleInvolved: { id: number; name: string; email: string; phone: string };
  timestamp: string;
}
const ExpenseCard = (prop: Prop) => {
  const { amount, expenseCategory, expenseLabel, group, paidBy, peopleInvolved, timestamp } = prop;
  const name = paidBy.name;

  return (
    <div style={flexRightBoxProfile}>
      <div style={flexHistoryProfile}>
        <div style={flexHistoryProfileImage}>
          <img src={zomato} height="15px" width="15px" />
        </div>
        <div style={flexHPSecond}>
          <div>
            <p style={flexHPImage}> {expenseLabel}</p>
          </div>
          <div style={imgText2}>
            <div>
              <img src={one} style={circleImage} height="15px" width="15px" />
            </div>
            <div>
              <p style={nameHistory}>{name}</p>
            </div>
          </div>
        </div>
        <div style={dateTimeMoney}>
          <p style={dateTimeMoneyAmount}>
            {amount < 0 ? '-' : ''}₹{amount}
          </p>
          <p style={dateTime}>{timestamp}</p>
        </div>
      </div>
    </div>
  );
};
export default ExpenseCard;
