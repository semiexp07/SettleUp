import { searchButton, searchButtonImage } from '../style/HomeStyle';
import search from '../assets/serachb.png';

const SearchButton = () => {
  return (
    <>
      <div>
        <button style={searchButton}>
          <img src={search} style={searchButtonImage} />
        </button>
      </div>
    </>
  );
};
export default SearchButton;
