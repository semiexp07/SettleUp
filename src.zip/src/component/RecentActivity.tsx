import { flexRightBoxRecent, recent } from '../style/HomeStyle';

const AddFriend = () => {
  return (
    <div style={flexRightBoxRecent}>
      <p style={recent}> Recent Activity</p>
    </div>
  );
};
export default AddFriend;
