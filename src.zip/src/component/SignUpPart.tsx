import { buttonLogin, input } from '../style/LoginStyle';
import { createHeading } from '../style/LoginStyle';
import { lebel } from '../style/LoginStyle';
import { useState } from 'react';
import { signUp } from '../style/LoginStyle';
import useRegistration from '../hook/useRegistration';

export type Creadential={
    email:string
    name:string
    password:string
    phone:string
}

const SignUpPart = () => {
    
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [phone,setPhone]=useState('');
  const [password,setPassword]=useState('');
 
  
  const onClick=()=>{
    
    const credentials:Creadential={
      email:email,
      name:name,
      password:password,
      phone:phone
    }
   useRegistration(credentials)
  }


  return (
    <div style={signUp}>
      <div style={createHeading}>CREATE ACCOUNT</div>
      <br />
      <div>
        <label style={lebel}>NAME *</label>
        <br />
        <input
          style={input}
          placeholder="YOUR NAME"
          onChange={(e) => setName(e.target.value)}
          
        ></input>
        <br />
        <label style={lebel}>EMAIL ID *</label>
        <br />
        <input
          style={input}
          placeholder="abc@gmail.com"
          onChange={(e) => setEmail(e.target.value)}
        ></input>
        <br />
        <label style={lebel}>MOBILE NUMBER *</label>
        <br />
        <input style={input} placeholder="+91 "  onChange={(e) => setPhone(e.target.value)}></input>
        <br />
        <label style={lebel}>PASSWORD *</label>
        <br />
        <input style={input} placeholder="XXX" onChange={(e) => setPassword(e.target.value)}></input>
      </div>
      <br />
      <div>
        <button style={buttonLogin} onClick={onClick}>Sign Up</button>
      </div>
    </div>
  );
};
export default SignUpPart;
