import { sqImg } from '../style/AddExpense';
import {
  amountPending,
  date,
  dateText,
  details,
  expenseHistoryCard,
  flexTextImg,
  headingText,
  month,
  monthTextBar,
  nameLoc,
  nameLocation,
  rupee,
} from '../style/FriendStyle';
import { circleImage } from '../style/HomeStyle';
import img1 from '../assets/netflix.png';
import one from '../assets/one.png';
import location from '../assets/location.png';
interface Prop {
  amount: number;
  expenseCategory: string;
  expenseLabel: string;
  group: {
    description: string;
    id: number;
    name: string;
    users: { id: number; name: string; email: string; phone: string }[];
  }[];
  paidBy: { id: number; name: string; email: string; phone: string };
  peopleInvolved: { id: number; name: string; email: string; phone: string };
  timestamp: string;
}

const FriendExpenseHistoryCard = (prop: Prop) => {
  const { amount, expenseCategory, expenseLabel, group, paidBy, peopleInvolved, timestamp } = prop;

  return (
    <div style={month}>
      <div style={monthTextBar}>January 2023</div>
      <div style={expenseHistoryCard}>
        <div style={date}>
          <p style={dateText}>Jan</p>
          <p style={dateText}>2</p>
        </div>
        <div style={sqImg}>
          <img src={img1} height="20px" width="20px" />
        </div>
        <div style={details}>
          <div>
            <p style={headingText}>{expenseLabel}</p>
          </div>
          <div style={nameLoc}>
            <div style={flexTextImg}>
              <div style={circleImage}>
                <img src={one} height="18px" width="18px" />
              </div>
              <div>
                <p style={nameLocation}>{paidBy.name} , in</p>
              </div>
            </div>
            <div style={flexTextImg}>
              <div style={circleImage}>
                <img src={location} height="18px" width="18px" />
              </div>
              <div>
                <p style={nameLocation}>bengaluru</p>
              </div>
            </div>
          </div>
        </div>
        <div style={rupee}>
          <p style={amountPending}>- ₹{amount}</p>
        </div>
      </div>
    </div>
  );
};
export default FriendExpenseHistoryCard;
