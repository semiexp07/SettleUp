import { crtBar, crtBarButton, crtBatAmount, crtBatText } from '../style/FriendStyle';
interface Prop {
  value: number;
}

const ReceiveRequestBox = (prop: Prop) => {
  const { value } = prop;
  return (
    <>
      <div>
        <div style={crtBar}>
          <div>
            <div>
              <p style={crtBatText}>Receive</p>
            </div>
            <div>
              <p style={crtBatAmount}>₹ {value}</p>
            </div>
          </div>
          <div>
            <button style={crtBarButton}>
              <p>Request</p>
            </button>
          </div>
        </div>
      </div>
    </>
  );
};
export default ReceiveRequestBox;
