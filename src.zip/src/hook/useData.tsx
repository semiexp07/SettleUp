import React, { createContext } from "react";
export const UserData=createContext({});
 const UseData=()=>{
    return (
        <UserData.Provider value={{name:"",id:0,token:""}}>
             
        </UserData.Provider>
    )
 }
export default UseData
