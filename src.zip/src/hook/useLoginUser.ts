import { createContext } from 'react';
import { useNavigate } from 'react-router-dom';
import DataContext from '../DataContext';
const UserData=createContext("");
type Props = {
  email: string;
  password: string;
};
const useLoginUser = (props: Props,setUser:(x:any)=>void) => {
  const credentials = props;

  async function fetchLogin(url = '', data: Props) {
    const response = await fetch(url, {
      method: 'POST',

      headers: {
        'Content-Type': 'application/json',
      },

      body: JSON.stringify(data),
    });
    return response.json();
  }

  fetchLogin('http://localhost:8080/api/v1/user/login', credentials).then((data) => {
   
    if (data !== null) {
      const token =data.token
      const name=data.userDetails.name
      const id=data.userDetails.id
      localStorage.setItem('token',token)
      setUser({name,token,id})
      
    }
  });
};
export default useLoginUser;
