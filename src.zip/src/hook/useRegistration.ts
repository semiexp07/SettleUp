type Props = {
  email: string;
  name: string;
  password: string;
  phone: string;
};
const useRegistration = (props: Props) => {
  const credentials = props;


  async function fetchRegistration(url = '', data: Props) {
    const response = await fetch(url, {
      method: 'POST',

      headers: {
        'Content-Type': 'application/json',
      },

      body: JSON.stringify(data),
    });
    const result = response.status;
    return result;
  }

  fetchRegistration('http://localhost:8080/api/v1/user/register', credentials).then((data) => {
    if (data == 201) {
      alert('Registration completed ,please logIn to edit your profile');
    } else {
      alert('Invalid input');
    }
  });
};
export default useRegistration;
