const useFetchActivity= () => {
    const userToken=localStorage.getItem('token');  
      async function fetchRegistration(url = '',userToken:any) {
          const response = await fetch(url, {
            method: 'GET',
            headers: {
              'Content-Type': 'application/json',
               'Authorization':`Bearer ${userToken}`
            },
          });
          const result = response.json();
          return result;
        }
      
        return fetchRegistration('http://localhost:8080/api/v1/dashboard/activities',userToken)
  }
  export default useFetchActivity