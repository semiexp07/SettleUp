import { body } from '../style/LoginStyle';
import LoginPart from '../component/LoginPart';
import SignUpPart from '../component/SignUpPart';
const Login = () => {
  return (
    <div style={body}>
      <LoginPart />
      <SignUpPart />
    </div>
  );
};

export default Login;
