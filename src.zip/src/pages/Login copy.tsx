import { body } from '../style/LoginStyle';
const SettleUp = () => {
  return <div style={body}></div>;
};

export default SettleUp;
