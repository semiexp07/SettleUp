import {
  prt,
  body,
  mainPopScreen,
  popHeader,
  total1,
  tAmt,
  total2,
  imgQues,
  sqImg,
  ques,
  input1,
  inputBox,
  todayGroup,
  tdyGrp,
  saveExp,
  saveExpense,
  groupInfo,
  today,
  add,
  inputText,
  inputBoxText,
  splitBetween,
  questionText,
  amount,
} from '../style/AddExpense';
import cut from '../assets/cut.svg';
import gellary from '../assets/gallary.svg';
import cel from '../assets/calender.svg';
import group from '../assets/grp-btn.svg';
const AddExpense = () => {
  return (
    <div style={prt}>
      <div style={body}>
        <div style={mainPopScreen}>
          <div style={popHeader}>
            <p style={total1}>Add Expense</p>
            <img src={cut} height="15px" width="15px" />
          </div>
          <div>
            <div style={tAmt}>
              <div>
                <p style={total2}>Total amount</p>
              </div>
              <div>
                <input style={amount} placeholder="₹000"></input>
              </div>
            </div>
            <div style={imgQues}>
              <div style={sqImg}>
                <img src={gellary} height="20px" width="20px" />
              </div>
              <div style={ques}>
                <input style={questionText} placeholder={'what is this expense for ?'}></input>
              </div>
            </div>
            <br />
            <div style={input1}>
              <div>
                <p style={splitBetween}>SPLIT BETWEEN</p>
              </div>
              <div>
                <div style={inputBox}>
                  <p style={inputBoxText}>+ Add friends</p>
                </div>
              </div>
            </div>
            <br />
            <div style={input1}>
              <div>
                <p style={inputText}>WHO PAID</p>
              </div>
              <div>
                <div style={inputBox}>
                  <p style={add}>+ Add</p>
                </div>
              </div>
            </div>
            <br />
            <div style={todayGroup}>
              <div style={tdyGrp}>
                <img src={cel} height="15px" width="15px" />
                <p style={today}>Today</p>
              </div>
              <div style={tdyGrp}>
                <img src={group} height="15px" width="15px" />
                <p style={groupInfo}>Group</p>
              </div>
            </div>
            <br />
            <br />
            <button style={saveExp}>
              <p style={saveExpense}>SAVE EXPENSE</p>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
export default AddExpense;
