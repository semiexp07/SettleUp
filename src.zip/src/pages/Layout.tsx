import { bodyDashboard, flexContainer, imgText, option } from '../style/LayoutStyle';
import Friend from './Friend';
import Home from './Home';
import { useState } from 'react';
import friend from '../assets/friends.svg';
import home from '../assets/Vector.svg';
import add from '../assets/add.svg';
import groups from '../assets/groups.svg';
import activity from '../assets/activity.svg';
import AddExpense from './AddExpense';
import Group from './Group';
import Activity from './Activity';
const Layout = () => {
  const [click, setClick] = useState('');
  const onClick1 = () => {
    setClick('home');
  };
  const onClick2 = () => {
    setClick('friend');
  };
  const onClick3 = () => {
    setClick('addExpense');
  };
  const onClick4 = () => {
    setClick('group');
  };
  const onClick5 = () => {
    setClick('activity');
  };

  return (
    <>
      <div style={bodyDashboard}>
        <div style={flexContainer}>
          <div style={option} onClick={onClick1}>
            <img src={home} />
            <p style={imgText}>home</p>
          </div>
          <div style={option} onClick={onClick2}>
            <img src={friend} />
            <p style={imgText}>friend</p>
          </div>
          <div style={option} onClick={onClick3}>
            <img src={add} />
          </div>
          <div style={option} onClick={onClick4}>
            <img src={groups} />
            <p style={imgText}>group</p>
          </div>
          <div style={option} onClick={onClick5}>
            <img src={activity} />
            <p style={imgText}>activity</p>
          </div>
        </div>
        <div>
          <div id="2">
            {click == 'home' ? (
              <Home />
            ) : click == 'friend' ? (
              <Friend />
            ) : click == 'addExpense' ? (
              <AddExpense />
            ) : click == 'group' ? (
              <Group />
            ) : click == 'activity' ? (
              <Activity />
            ) : (
              <Home />
            )}
          </div>
        </div>
      </div>
    </>
  );
};

export default Layout;
