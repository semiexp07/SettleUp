import { body } from "../style/GroupStyle"
import { headerMain,searchAddFriend } from "../style/HomeStyle"
import ImageName from "../component/ImageName"
import SearchButton from "../component/SearchButton"
import GroupDetailCard from "../component/GroupDetailCard"
import YourFriendTitle from "../component/YourFriendTitle"
import { useState ,useEffect} from "react"
import useFetchGroup from "../hook/useFetchGroup"
const Group=()=>{


    const [group, setGroup] =
    useState<
      {
        description: string;
        friends: { balance: number; id: number; name: string }[];
        id: number;
        name: string;
      }[]
    >();
    useEffect(() => {
        
        useFetchGroup().then((response) => {
          setGroup(response);
        });
      }, []);






    return (<>

    
    <div style={body}>
        
    <div style={headerMain}>
            <ImageName />
            <div style={searchAddFriend}>
              <SearchButton />
              <SearchButton />
              
            </div>
    </div>
       <YourFriendTitle/>

       <div >
       {!!group && (
          <div>
            {group.map((obj) => {
              return <GroupDetailCard key={'group' + obj.id} {...obj} />;
            })}
          </div>
        )}
       </div>
       
    </div>
    
    </>)
}
export default Group