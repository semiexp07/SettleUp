import { body, grid1, grid2, friendHeader, gridGayab } from '../style/FriendStyle';
import { headerMain, headerMain2, searchAddFriend } from '../style/HomeStyle';
import ImageName from '../component/ImageName';
import SearchButton from '../component/SearchButton';
import AddFriend from '../component/AddFriend';
import YourFriendTitle from '../component/YourFriendTitle';
import FriendExpenseCard from '../component/FriendExpenseCard';
import ReceiveRequestBox from '../component/ReceiveRequestBar';
import FriendExpenseHistoryCard from '../component/FriendExpenseHistoryCard';
import { useState, useEffect } from 'react';
import useFetch from '../hook/useFetch';
import ThreeDot from '../component/ThreeDot';
import useFetchActivity from '../hook/useFetchActivity';

interface Expense {
  amount: number;
  expenseCategory: string;
  expenseLabel: string;
  group: {
    description: string;
    id: number;
    name: string;
    users: { id: number; name: string; email: string; phone: string }[];
  }[];
  paidBy: { id: number; name: string; email: string; phone: string };
  peopleInvolved: { id: number; name: string; email: string; phone: string };
  timestamp: string;
}

const Friend = () => {
  const [friend, setFriends] = useState<{ id: number; name: string; balance: number }[]>();
  const [activity, setActivity] = useState<Expense[]>();

  useEffect(() => {
    useFetch().then((response) => {
      setFriends(response);
    });
    useFetchActivity().then((response) => {
      setActivity(response);
    });
  }, []);

  const [click, setClick] = useState('none');

  const onClick = () => {
    setClick('hey');
  };
  let total = 0;
  activity?.map((obj) => {
    total += obj.amount;
  });
  const amount = { value: total };

  return (
    <>
      <div style={body}>
        <div style={grid1}>
          <div style={friendHeader}>
            <div style={headerMain}>
              <ImageName />
              <div style={searchAddFriend}>
                <SearchButton />
                <AddFriend />
              </div>
            </div>
            <YourFriendTitle />
          </div>

          <div onClick={onClick}>
            {!!friend && (
              <div>
                {friend.map((obj) => {
                  return <FriendExpenseCard key={'friend' + obj.id} {...obj} />;
                })}
              </div>
            )}
          </div>
        </div>
        <div style={click == 'none' ? gridGayab : grid2}>
          <div style={friendHeader}>
            <div style={headerMain2}>
              <ImageName />
              <div style={searchAddFriend}>
                <SearchButton />
                <ThreeDot />
              </div>
            </div>
          </div>
          <ReceiveRequestBox {...amount} />
          {!!activity && (
            <div>
              {activity.map((obj) => {
                return (
                  <FriendExpenseHistoryCard
                    key={'expense' + obj.expenseCategory + Math.random.toString}
                    {...obj}
                  />
                );
              })}
            </div>
          )}
        </div>
      </div>
    </>
  );
};

export default Friend;
