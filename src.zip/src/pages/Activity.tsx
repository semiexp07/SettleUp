import ImageName from '../component/ImageName';
import SearchButton from '../component/SearchButton';
import { headerMain, searchAddFriend, flexRightBox } from '../style/HomeStyle';

import RecentActivity from '../component/RecentActivity';
import ExpenseCard from '../component/ExpenseCard';
import { useState, useEffect } from 'react';
import useFetchActivity from '../hook/useFetchActivity';

interface Expense {
  amount: number;
  expenseCategory: string;
  expenseLabel: string;
  group: {
    description: string;
    id: number;
    name: string;
    users: { id: number; name: string; email: string; phone: string }[];
  }[];
  paidBy: { id: number; name: string; email: string; phone: string };
  peopleInvolved: { id: number; name: string; email: string; phone: string };
  timestamp: string;
}

const Activity = () => {
  const [activity, setActivity] = useState<Expense[]>();

  useEffect(() => {
    useFetchActivity().then((response) => {
      setActivity(response);
    });
  }, []);

  return (
    <div style={{ display: 'flex', flexDirection: 'column' }}>
      <div style={headerMain}>
        <ImageName />
        <div style={searchAddFriend}>
          <SearchButton />
        </div>
      </div>
      <div style={flexRightBox}>
        <RecentActivity />

        {!!activity && (
          <div>
            {activity.map((obj) => {
              return (
                <ExpenseCard
                  key={'expense' + obj.expenseCategory + Math.random.toString}
                  {...obj}
                />
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};
export default Activity;
