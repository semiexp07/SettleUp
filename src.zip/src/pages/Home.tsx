import AddFriend from '../component/AddFriend';
import ExpenseBar from '../component/ExpenseBar';
import ImageName from '../component/ImageName';
import SearchButton from '../component/SearchButton';
import NetWorthBar from '../component/NetWorthBar';
import FriendViewAll from '../component/FriendViewAll';
import {
  pendingPay,
  body,
  header,
  leftBody,
  headerMain,
  searchAddFriend,
  flexGroup,
  flexRightBox,
  borderLeft,
} from '../style/HomeStyle';
import FriendCard from '../component/FriendCard';
import GroupViewAll from '../component/GroupViewAll';
import GroupCard from '../component/GroupCard';
import RecentActivity from '../component/RecentActivity';
import ExpenseCard from '../component/ExpenseCard';
import { useState, useEffect } from 'react';
import useFetch from '../hook/useFetch';
import useFetchGroup from '../hook/useFetchGroup';
import useFetchActivity from '../hook/useFetchActivity';
import { useBalance } from '../hook/useBalance';
interface Expense {
  amount: number;
  expenseCategory: string;
  expenseLabel: string;
  group: {
    description: string;
    id: number;
    name: string;
    users: { id: number; name: string; email: string; phone: string }[];
  }[];
  paidBy: { id: number; name: string; email: string; phone: string };
  peopleInvolved: { id: number; name: string; email: string; phone: string };
  timestamp: string;
}

const Home = () => {
  const [balance, setBalance] = useState<{
    amountToReceive: number;
    amountToPay: number;
  }>();

  const [friend, setFriends] = useState<{ id: number; name: string; balance: number }[]>();

  const [group, setGroup] = useState<
    {
      description: string;
      friends: { balance: number; id: number; name: string }[];
      id: number;
      name: string;
    }[]
  >();
  const [activity, setActivity] = useState<Expense[]>();

  useEffect(() => {
    useFetch().then((response) => {
      setFriends(response);
    });
    useFetchGroup().then((response) => {
      setGroup(response);
    });
    useFetchActivity().then((response) => {
      setActivity(response);
    });
    useBalance().then((result) => {
      setBalance(result);
    });
  }, []);

  return (
    <div style={body}>
      <div style={leftBody}>
        <div style={header}>
          <div style={headerMain}>
            <ImageName />
            <div style={searchAddFriend}>
              <SearchButton />
              <AddFriend />
            </div>
          </div>
          <div>
            <ExpenseBar {...balance} />
          </div>
          <div>
            <NetWorthBar {...balance} />
          </div>
        </div>

        <FriendViewAll />

        {!!friend && (
          <div style={pendingPay}>
            {friend.map((obj) => {
              return <FriendCard key={'friend' + obj.id} {...obj} />;
            })}
          </div>
        )}

        <GroupViewAll />

        {!!group && (
          <div style={flexGroup}>
            {group.map((obj) => {
              return <GroupCard key={'group' + obj.id} {...obj} />;
            })}
          </div>
        )}
      </div>

      <div style={borderLeft}>
        <div style={flexRightBox}>
          <RecentActivity />

          {!!activity && (
            <div>
              {activity.map((obj) => {
                return (
                  <ExpenseCard
                    key={'expense' + obj.expenseCategory + Math.random.toString}
                    {...obj}
                  />
                );
              })}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default Home;
